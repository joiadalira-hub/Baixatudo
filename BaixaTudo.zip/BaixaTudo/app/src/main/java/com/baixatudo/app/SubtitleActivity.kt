package com.baixatudo.app

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.baixatudo.app.databinding.ActivitySubtitleBinding
import com.google.android.material.slider.Slider
import kotlinx.coroutines.launch

class SubtitleActivity : AppCompatActivity() {

    companion object { const val EXTRA_VIDEO = "video" }

    private lateinit var b: ActivitySubtitleBinding
    private val vm: SubtitleViewModel by viewModels()
    private val prefs by lazy { getSharedPreferences("config", MODE_PRIVATE) }

    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            vm.load(uri)
        }
    }

    private val pickFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            prefs.edit().putString("tree", uri.toString()).apply()
            vm.process(b.regionView.region, uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivitySubtitleBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.btnBack.setOnClickListener { finish() }
        b.btnPick.setOnClickListener { pickVideo.launch(arrayOf("video/*")) }
        b.btnPreview.setOnClickListener {
            if (vm.state.value.preview != null) vm.clearPreview() else vm.preview(b.regionView.region)
        }
        b.btnProcess.setOnClickListener { startProcess() }
        b.btnCancel.setOnClickListener { vm.cancel() }

        b.regionView.onRegionChanged = {
            if (vm.state.value.preview != null) vm.clearPreview()
            saveRegion()
        }
        restoreRegion()

        b.timeSlider.setLabelFormatter { f -> formatTime((vm.state.value.durationMs * f).toLong()) }
        b.timeSlider.addOnSliderTouchListener(object : Slider.OnSliderTouchListener {
            override fun onStartTrackingTouch(slider: Slider) = Unit
            override fun onStopTrackingTouch(slider: Slider) = vm.seek(slider.value)
        })

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) { vm.state.collect(::render) }
        }

        if (savedInstanceState == null) videoFromIntent(intent)?.let(vm::load)
    }

    private fun videoFromIntent(i: Intent?): Uri? {
        i ?: return null
        i.getStringExtra(EXTRA_VIDEO)?.let { return Uri.parse(it) }
        if (i.action == Intent.ACTION_SEND) {
            return if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
            else @Suppress("DEPRECATION") i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
        }
        return i.data
    }

    private fun startProcess() {
        val tree = prefs.getString("tree", null)?.let(Uri::parse)?.takeIf { uri ->
            contentResolver.persistedUriPermissions.any { it.uri == uri && it.isWritePermission }
        }
        if (tree == null) {
            Toast.makeText(this, R.string.choose_folder_first, Toast.LENGTH_LONG).show()
            pickFolder.launch(null)
        } else {
            vm.process(b.regionView.region, tree)
        }
    }

    private fun render(s: SubState) {
        b.regionView.bitmap = s.preview ?: s.frame
        b.regionView.previewMode = s.preview != null

        b.timeRow.visibility = if (s.loaded) View.VISIBLE else View.GONE
        if (s.durationMs > 0 && !b.timeSlider.isPressed) {
            b.timeSlider.value = (s.positionMs.toFloat() / s.durationMs).coerceIn(0f, 1f)
        }
        b.timeText.text = "${formatTime(s.positionMs)} / ${formatTime(s.durationMs)}"

        b.statusText.text = s.status.ifEmpty { getString(R.string.sub_intro) }
        b.detailText.text = s.detail
        b.detailText.visibility = if (s.detail.isBlank()) View.GONE else View.VISIBLE

        b.btnPick.isEnabled = !s.busy
        b.btnPreview.isEnabled = s.loaded && !s.busy
        b.btnPreview.setText(if (s.preview != null) R.string.edit_area else R.string.preview)
        b.btnProcess.isEnabled = s.loaded && !s.busy
        b.timeSlider.isEnabled = !s.busy
        b.btnCancel.visibility = if (s.processing) View.VISIBLE else View.GONE

        val bar = b.progress
        if (!s.busy && s.progress <= 0) {
            bar.visibility = View.INVISIBLE
        } else {
            val ind = s.progress < 0
            if (bar.isIndeterminate != ind) { bar.visibility = View.INVISIBLE; bar.isIndeterminate = ind }
            bar.visibility = View.VISIBLE
            if (!ind) bar.setProgressCompat(s.progress, true)
        }
    }

    // A área marcada fica salva: vídeos do mesmo perfil costumam ter a legenda no mesmo lugar
    private fun saveRegion() {
        val r = b.regionView.region
        prefs.edit().putString("region", "${r.left},${r.top},${r.right},${r.bottom}").apply()
    }

    private fun restoreRegion() {
        val p = prefs.getString("region", null)?.split(",")?.mapNotNull { it.toFloatOrNull() } ?: return
        if (p.size == 4) b.regionView.setRegion(android.graphics.RectF(p[0], p[1], p[2], p[3]))
    }

    private fun formatTime(ms: Long): String {
        val t = ms / 1000
        return "%d:%02d".format(t / 60, t % 60)
    }
}
