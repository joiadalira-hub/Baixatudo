package com.baixatudo.app

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.RectF
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File
import java.util.Locale

data class SubState(
    val loaded: Boolean = false,
    val frame: Bitmap? = null,
    val preview: Bitmap? = null,
    val durationMs: Long = 0,
    val positionMs: Long = 0,
    val busy: Boolean = false,
    val processing: Boolean = false,
    val progress: Int = 0,          // 0..100, -1 = indeterminado
    val status: String = "",
    val detail: String = "",
)

class SubtitleViewModel(app: Application) : AndroidViewModel(app) {

    private val _state = MutableStateFlow(SubState())
    val state = _state.asStateFlow()

    private var uri: Uri? = null
    private var displayName = "video"
    private var mime: String? = null
    private var videoW = 0
    private var videoH = 0

    private val work = File(app.cacheDir, "legendas").apply { mkdirs() }
    private var localCopy: File? = null
    private val copyLock = Mutex()
    private var frameJob: Job? = null

    @Volatile private var process: Process? = null
    @Volatile private var cancelled = false

    // ------------------------------------------------------------ carregar

    fun load(newUri: Uri) {
        if (newUri == uri) return
        uri = newUri
        localCopy?.delete(); localCopy = null
        viewModelScope.launch(Dispatchers.IO) {
            _state.update { SubState(busy = true, progress = -1, status = "Abrindo o vídeo…") }
            try {
                val ctx = getApplication<Application>()
                mime = ctx.contentResolver.getType(newUri)
                displayName = queryName(newUri)?.substringBeforeLast('.') ?: "video"

                val mmr = MediaMetadataRetriever()
                try {
                    mmr.setDataSource(ctx, newUri)
                    val duration = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                    val w = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
                    val h = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
                    val rot = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                    if (rot == 90 || rot == 270) { videoW = h; videoH = w } else { videoW = w; videoH = h }

                    val pos = duration / 3
                    val bmp = grabFrame(mmr, pos) ?: error("Não consegui ler as imagens desse vídeo.")
                    if (videoW <= 0 || videoH <= 0) { videoW = bmp.width; videoH = bmp.height }

                    _state.update {
                        it.copy(loaded = true, frame = shrink(bmp), durationMs = duration, positionMs = pos,
                            busy = false, progress = 0,
                            status = "Arraste o retângulo para cima da legenda e ajuste o tamanho.")
                    }
                } finally {
                    mmr.release()
                }
            } catch (e: Exception) {
                uri = null
                _state.update { SubState(status = "❌ Não foi possível abrir: ${e.message}") }
            }
        }
    }

    /** Mostra outro momento do vídeo (para achar um quadro com legenda). */
    fun seek(fraction: Float) {
        val u = uri ?: return
        val pos = (_state.value.durationMs * fraction).toLong()
        frameJob?.cancel()
        frameJob = viewModelScope.launch(Dispatchers.IO) {
            val mmr = MediaMetadataRetriever()
            try {
                mmr.setDataSource(getApplication(), u)
                val bmp = grabFrame(mmr, pos) ?: return@launch
                _state.update { it.copy(frame = shrink(bmp), preview = null, positionMs = pos) }
            } catch (_: Exception) {
            } finally {
                mmr.release()
            }
        }
    }

    fun clearPreview() = _state.update { it.copy(preview = null) }

    // ------------------------------------------------------------ prévia

    fun preview(region: RectF) {
        if (_state.value.busy || !_state.value.loaded) return
        viewModelScope.launch(Dispatchers.IO) {
            _state.update { it.copy(busy = true, progress = -1, status = "Gerando prévia…") }
            try {
                val input = ensureLocalCopy()
                val out = File(work, "previa.jpg").apply { delete() }
                val sec = String.format(Locale.US, "%.3f", _state.value.positionMs / 1000.0)
                val r = Engine.ffmpeg(getApplication(), listOf(
                    "-ss", sec, "-i", input.absolutePath,
                    "-filter_complex", filter(region), "-map", "[v]",
                    "-frames:v", "1", "-q:v", "3", out.absolutePath,
                ))
                if (r.exitCode != 0 || !out.exists()) error(lastError(r.log))
                val bmp = BitmapFactory.decodeFile(out.absolutePath) ?: error("Prévia vazia")
                _state.update {
                    it.copy(preview = shrink(bmp), busy = false, progress = 0,
                        status = "Prévia do resultado. Se ficar bom, toque em \"Remover legenda\".")
                }
            } catch (e: Exception) {
                _state.update { it.copy(busy = false, progress = 0, status = "❌ Falha na prévia: ${e.message}") }
            }
        }
    }

    // ------------------------------------------------------------ processar

    fun process(region: RectF, treeUri: Uri) {
        if (_state.value.busy || !_state.value.loaded) return
        cancelled = false
        viewModelScope.launch(Dispatchers.IO) {
            _state.update { it.copy(busy = true, processing = true, progress = -1, status = "Preparando…", detail = "") }
            val out = File(work, "saida.mp4").apply { delete() }
            try {
                val input = ensureLocalCopy()
                val totalUs = _state.value.durationMs * 1000
                // MP4/MOV: copia o áudio sem mexer. Outros formatos: converte para AAC.
                val copyAudio = (mime ?: "") in setOf("video/mp4", "video/quicktime", "video/3gpp")
                val audio = if (copyAudio) listOf("-c:a", "copy") else listOf("-c:a", "aac", "-b:a", "192k")

                val r = Engine.ffmpeg(
                    getApplication(),
                    listOf(
                        "-i", input.absolutePath,
                        "-filter_complex", filter(region),
                        "-map", "[v]", "-map", "0:a?",
                        "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
                    ) + audio + listOf(
                        "-movflags", "+faststart",
                        "-progress", "pipe:1", "-nostats",
                        out.absolutePath,
                    ),
                    onStart = { process = it },
                    onStdout = { line ->
                        if (line.startsWith("out_time_us=") && totalUs > 0) {
                            val us = line.substringAfter('=').toLongOrNull() ?: return@ffmpeg
                            val pct = (us * 100 / totalUs).toInt().coerceIn(0, 99)
                            _state.update { it.copy(progress = pct, status = "Removendo legenda… $pct%") }
                        }
                    },
                )
                process = null
                if (cancelled) error("cancelado")
                if (r.exitCode != 0 || out.length() == 0L) error(lastError(r.log))

                _state.update { it.copy(progress = -1, status = "Salvando…") }
                val name = save(out, treeUri, "$displayName (sem legenda).mp4")
                _state.update { it.copy(progress = 100, status = "✅ Pronto!", detail = "Salvo: $name") }
            } catch (e: Exception) {
                val msg = if (cancelled) "Cancelado." else "❌ Falhou: ${e.message}"
                _state.update { it.copy(progress = 0, status = msg) }
            } finally {
                out.delete()
                process = null
                _state.update { it.copy(busy = false, processing = false) }
            }
        }
    }

    fun cancel() {
        cancelled = true
        process?.destroy()
    }

    // ------------------------------------------------------------ helpers

    /**
     * delogo apaga a área preenchendo com os pixels das bordas; depois um leve
     * desfoque só dentro da área deixa a "emenda" bem menos visível.
     */
    private fun filter(region: RectF): String {
        val w0 = videoW; val h0 = videoH
        // O delogo não aceita encostar na borda do vídeo: deixa 2px de margem
        val x = (region.left * w0).toInt().coerceIn(2, w0 - 20)
        val y = (region.top * h0).toInt().coerceIn(2, h0 - 20)
        val w = (region.width() * w0).toInt().coerceIn(16, w0 - x - 2)
        val h = (region.height() * h0).toInt().coerceIn(16, h0 - y - 2)
        val blur = (min(w, h) / 8).coerceIn(2, 6)
        return "[0:v]delogo=x=$x:y=$y:w=$w:h=$h,split[m][r];" +
            "[r]crop=$w:$h:$x:$y,boxblur=$blur:1[b];" +
            "[m][b]overlay=$x:$y,format=yuv420p[v]"
    }

    private fun min(a: Int, b: Int) = if (a < b) a else b

    private suspend fun ensureLocalCopy(): File = copyLock.withLock {
        localCopy?.takeIf { it.exists() }?.let { return it }
        val u = uri ?: error("Nenhum vídeo aberto")
        _state.update { it.copy(status = "Copiando o vídeo…") }
        val ext = when (mime) {
            "video/webm" -> "webm"; "video/x-matroska" -> "mkv"; "video/quicktime" -> "mov"; else -> "mp4"
        }
        val f = File(work, "entrada.$ext")
        getApplication<Application>().contentResolver.openInputStream(u)?.use { input ->
            f.outputStream().use { input.copyTo(it, 256 * 1024) }
        } ?: error("Não consegui ler o arquivo")
        localCopy = f
        f
    }

    private fun save(file: File, treeUri: Uri, name: String): String {
        val ctx = getApplication<Application>()
        val dir = DocumentFile.fromTreeUri(ctx, treeUri) ?: error("Pasta inválida")
        val target = dir.createFile("video/mp4", name) ?: error("Não consegui criar o arquivo na pasta")
        ctx.contentResolver.openOutputStream(target.uri)?.use { out ->
            file.inputStream().use { it.copyTo(out, 256 * 1024) }
        } ?: error("Não consegui gravar o arquivo")
        return target.name ?: name
    }

    private fun grabFrame(mmr: MediaMetadataRetriever, posMs: Long): Bitmap? =
        mmr.getFrameAtTime(posMs * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
            ?: mmr.getFrameAtTime(0)

    private fun shrink(b: Bitmap): Bitmap {
        val max = 1280
        if (b.width <= max && b.height <= max) return b
        val s = max.toFloat() / maxOf(b.width, b.height)
        return Bitmap.createScaledBitmap(b, (b.width * s).toInt(), (b.height * s).toInt(), true)
    }

    private fun queryName(u: Uri): String? = runCatching {
        getApplication<Application>().contentResolver
            .query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
    }.getOrNull()

    private fun lastError(log: String): String =
        log.lines().map { it.trim() }.lastOrNull { it.isNotEmpty() && !it.startsWith("[") }?.take(200)
            ?: "erro desconhecido"

    override fun onCleared() {
        process?.destroy()
        work.deleteRecursively()
    }
}
