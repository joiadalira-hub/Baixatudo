package com.baixatudo.app

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.RectF
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.opencv.android.Utils
import org.opencv.core.Mat
import org.opencv.imgproc.Imgproc
import java.io.File
import java.io.IOException
import java.util.Locale
import kotlin.math.roundToInt

/** Como remover a legenda. */
enum class RemoveMode { PRECISE, STRONG, FAST }

data class SubState(
    val loaded: Boolean = false,
    val frame: Bitmap? = null,
    val preview: Bitmap? = null,
    val durationMs: Long = 0,
    val positionMs: Long = 0,
    val busy: Boolean = false,
    val processing: Boolean = false,
    val progress: Int = 0,          // 0..100, -1 = indeterminado
    val status: String = "",
    val detail: String = "",
)

class SubtitleViewModel(app: Application) : AndroidViewModel(app) {

    private val _state = MutableStateFlow(SubState())
    val state = _state.asStateFlow()

    private var uri: Uri? = null
    private var displayName = "video"
    private var mime: String? = null
    private var videoW = 0
    private var videoH = 0
    private var fps = 30.0

    private val work = File(app.cacheDir, "legendas").apply { mkdirs() }
    private var localCopy: File? = null
    private val copyLock = Mutex()
    private var frameJob: Job? = null

    private val running = mutableListOf<Engine.Running>()
    @Volatile private var process: Process? = null
    @Volatile private var cancelled = false

    // ------------------------------------------------------------ carregar

    fun load(newUri: Uri) {
        if (newUri == uri) return
        uri = newUri
        localCopy?.delete(); localCopy = null
        viewModelScope.launch(Dispatchers.IO) {
            _state.update { SubState(busy = true, progress = -1, status = "Abrindo o vídeo…") }
            try {
                val ctx = getApplication<Application>()
                Engine.init(ctx)
                mime = ctx.contentResolver.getType(newUri)
                displayName = queryName(newUri)?.substringBeforeLast('.') ?: "video"

                val mmr = MediaMetadataRetriever()
                try {
                    mmr.setDataSource(ctx, newUri)
                    fun meta(k: Int) = mmr.extractMetadata(k)
                    val duration = meta(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                    val w = meta(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
                    val h = meta(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
                    val rot = meta(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                    if (rot == 90 || rot == 270) { videoW = h; videoH = w } else { videoW = w; videoH = h }

                    fps = 30.0
                    if (Build.VERSION.SDK_INT >= 28 && duration > 0) {
                        val count = meta(MediaMetadataRetriever.METADATA_KEY_VIDEO_FRAME_COUNT)?.toLongOrNull()
                        if (count != null && count > 0) fps = (count * 1000.0 / duration).coerceIn(5.0, 120.0)
                    }

                    val pos = duration / 3
                    val bmp = grabFrame(mmr, pos) ?: error("Não consegui ler as imagens desse vídeo.")
                    if (videoW <= 0 || videoH <= 0) { videoW = bmp.width; videoH = bmp.height }

                    _state.update {
                        it.copy(loaded = true, frame = shrink(bmp), durationMs = duration, positionMs = pos,
                            busy = false, progress = 0,
                            status = "Arraste o retângulo para cima da legenda e ajuste o tamanho.")
                    }
                } finally {
                    mmr.release()
                }
            } catch (e: Exception) {
                uri = null
                _state.update { SubState(status = "❌ Não foi possível abrir: ${e.message}") }
            }
        }
    }

    /** Mostra outro momento do vídeo (para achar um quadro com legenda). */
    fun seek(fraction: Float) {
        val u = uri ?: return
        val pos = (_state.value.durationMs * fraction).toLong()
        frameJob?.cancel()
        frameJob = viewModelScope.launch(Dispatchers.IO) {
            val mmr = MediaMetadataRetriever()
            try {
                mmr.setDataSource(getApplication(), u)
                val bmp = grabFrame(mmr, pos) ?: return@launch
                _state.update { it.copy(frame = shrink(bmp), preview = null, positionMs = pos) }
            } catch (_: Exception) {
            } finally {
                mmr.release()
            }
        }
    }

    fun clearPreview() = _state.update { it.copy(preview = null) }

    // ------------------------------------------------------------ prévia

    fun preview(region: RectF, mode: RemoveMode) {
        if (_state.value.busy || !_state.value.loaded) return
        cancelled = false
        viewModelScope.launch(Dispatchers.IO) {
            _state.update { it.copy(busy = true, progress = -1, status = "Gerando prévia…") }
            try {
                val input = ensureLocalCopy()
                _state.update { it.copy(status = "Gerando prévia…") }
                val bmp = if (mode == RemoveMode.FAST) previewFast(input, region) else previewPrecise(input, region, mode)
                _state.update {
                    it.copy(preview = shrink(bmp), busy = false, progress = 0,
                        status = "Prévia do resultado. Se ficar bom, toque em \"Remover legenda\".")
                }
            } catch (e: Exception) {
                _state.update { it.copy(busy = false, progress = 0, status = "❌ Falha na prévia: ${e.message}") }
            } finally {
                stopAll()
            }
        }
    }

    private fun previewFast(input: File, region: RectF): Bitmap {
        val out = File(work, "previa.jpg").apply { delete() }
        val r = Engine.ffmpeg(getApplication(), listOf(
            "-ss", sec(_state.value.positionMs), "-i", input.absolutePath,
            "-filter_complex", delogoFilter(region), "-map", "[v]",
            "-frames:v", "1", "-q:v", "3", out.absolutePath,
        ))
        if (r.exitCode != 0 || !out.exists()) error(lastError(r.log))
        return BitmapFactory.decodeFile(out.absolutePath) ?: error("Prévia vazia")
    }

    /**
     * O modo preciso precisa dos quadros vizinhos, então processa ~3 segundos em volta
     * do momento escolhido e mostra o quadro do meio.
     */
    private fun previewPrecise(input: File, region: RectF, mode: RemoveMode): Bitmap {
        val pos = _state.value.positionMs
        val startMs = (pos - 1500).coerceAtLeast(0)
        val mid = ((pos - startMs) / 1000.0 * fps).roundToInt()
        val remover = newRemover(region, mode)
        val fpsStr = fpsStr()
        try {
            // Quadro original inteiro, exatamente o mesmo que o removedor vai tratar
            val full = File(work, "previa_full.png").apply { delete() }
            val rf = Engine.ffmpeg(getApplication(), listOf(
                "-ss", sec(startMs), "-t", "3", "-i", input.absolutePath,
                "-vf", "fps=$fpsStr,select='gte(n,$mid)'", "-fps_mode", "passthrough",
                "-frames:v", "1", full.absolutePath,
            ))
            if (rf.exitCode != 0 || !full.exists()) error(lastError(rf.log))
            val base = BitmapFactory.decodeFile(full.absolutePath)?.copy(Bitmap.Config.ARGB_8888, true)
                ?: error("Prévia vazia")

            val dec = startDecoder(input, remover, startMs, 3.0)
            var strip: Bitmap? = null
            remover.run(
                dec.process.inputStream,
                onFrame = { i, mat -> if (i >= mid && strip == null) strip = matToBitmap(mat) },
                isCancelled = { cancelled || strip != null },
            )
            dec.destroy()
            val s = strip ?: error("Não consegui gerar a prévia nesse ponto do vídeo.")
            Canvas(base).drawBitmap(s, remover.stripX.toFloat(), remover.stripY.toFloat(), null)
            return base
        } finally {
            remover.release()
        }
    }

    // ------------------------------------------------------------ processar

    fun process(region: RectF, treeUri: Uri, mode: RemoveMode) {
        if (_state.value.busy || !_state.value.loaded) return
        cancelled = false
        viewModelScope.launch(Dispatchers.IO) {
            _state.update { it.copy(busy = true, processing = true, progress = -1, status = "Preparando…", detail = "") }
            val out = File(work, "saida.mp4").apply { delete() }
            try {
                val input = ensureLocalCopy()
                if (mode == RemoveMode.FAST) processFast(input, region, out) else processPrecise(input, region, mode, out)
                if (cancelled) error("cancelado")

                _state.update { it.copy(progress = -1, status = "Salvando…") }
                val name = save(out, treeUri, "$displayName (sem legenda).mp4")
                _state.update { it.copy(progress = 100, status = "✅ Pronto!", detail = "Salvo: $name") }
            } catch (e: Exception) {
                val msg = if (cancelled) "Cancelado." else "❌ Falhou: ${e.message}"
                _state.update { it.copy(progress = 0, status = msg) }
            } finally {
                stopAll()
                out.delete()
                _state.update { it.copy(busy = false, processing = false) }
            }
        }
    }

    private fun audioArgs(): List<String> {
        // MP4/MOV: copia o áudio sem mexer. Outros formatos: converte para AAC.
        val copy = (mime ?: "") in setOf("video/mp4", "video/quicktime", "video/3gpp")
        return if (copy) listOf("-c:a", "copy") else listOf("-c:a", "aac", "-b:a", "192k")
    }

    private fun processFast(input: File, region: RectF, out: File) {
        val totalUs = _state.value.durationMs * 1000
        val r = Engine.ffmpeg(
            getApplication(),
            listOf(
                "-i", input.absolutePath,
                "-filter_complex", delogoFilter(region),
                "-map", "[v]", "-map", "0:a?",
                "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
            ) + audioArgs() + listOf(
                "-movflags", "+faststart", "-progress", "pipe:1", "-nostats", out.absolutePath,
            ),
            onStart = { process = it },
            onStdout = { line ->
                if (line.startsWith("out_time_us=") && totalUs > 0) {
                    val us = line.substringAfter('=').toLongOrNull() ?: return@ffmpeg
                    val pct = (us * 100 / totalUs).toInt().coerceIn(0, 99)
                    _state.update { it.copy(progress = pct, status = "Removendo legenda… $pct%") }
                }
            },
        )
        process = null
        if (!cancelled && (r.exitCode != 0 || out.length() == 0L)) error(lastError(r.log))
    }

    /**
     * Dois FFmpeg ligados por pipe:
     *   decodificador -> (só a faixa da legenda, quadro a quadro) -> TextRemover -> codificador
     * O codificador cola a faixa limpa por cima do vídeo original e mantém o áudio.
     */
    private fun processPrecise(input: File, region: RectF, mode: RemoveMode, out: File) {
        val remover = newRemover(region, mode)
        try {
            val f = fpsStr()
            val total = (_state.value.durationMs / 1000.0 * fps).roundToInt().coerceAtLeast(1)
            val dec = startDecoder(input, remover, null, null)
            val enc = Engine.start(getApplication(), listOf(
                "-i", input.absolutePath,
                "-f", "rawvideo", "-pix_fmt", "bgr24",
                "-s", "${remover.stripW}x${remover.stripH}", "-framerate", f, "-i", "pipe:0",
                "-filter_complex",
                "[0:v]fps=$f,setpts=N/($f*TB)[b];[1:v]setpts=N/($f*TB)[o];" +
                    "[b][o]overlay=${remover.stripX}:${remover.stripY}:eof_action=pass,format=yuv420p[v]",
                "-map", "[v]", "-map", "0:a?",
                "-c:v", "libx264", "-preset", "veryfast", "-crf", "18",
            ) + audioArgs() + listOf("-movflags", "+faststart", out.absolutePath))
            synchronized(running) { running += enc }

            val buf = ByteArray(remover.stripW * remover.stripH * 3)
            val sink = enc.process.outputStream.buffered(1 shl 20)
            val started = System.currentTimeMillis()
            var writeError: IOException? = null
            try {
                remover.run(
                    dec.process.inputStream,
                    onFrame = { i, mat ->
                        mat.get(0, 0, buf)
                        sink.write(buf)
                        if (i % 5 == 0) {
                            val pct = (i * 100 / total).coerceIn(0, 99)
                            val elapsed = (System.currentTimeMillis() - started) / 1000.0
                            val eta = if (i > 10) ((total - i) * elapsed / i).toLong() else -1
                            _state.update {
                                it.copy(progress = pct,
                                    status = "Removendo legenda… $pct%" + if (eta > 0) "  •  faltam ${formatEta(eta)}" else "",
                                    detail = "Quadro $i de $total")
                            }
                        }
                    },
                    isCancelled = { cancelled },
                )
                sink.close()
            } catch (e: IOException) {
                writeError = e
            }

            if (cancelled) return
            _state.update { it.copy(progress = -1, status = "Finalizando o vídeo…") }
            val encCode = enc.waitFor()
            dec.waitFor()
            if (writeError != null || encCode != 0 || out.length() == 0L) error(lastError(enc.log()))
        } finally {
            remover.release()
        }
    }

    fun cancel() {
        cancelled = true
        process?.destroy()
        stopAll()
    }

    // ------------------------------------------------------------ helpers

    private fun newRemover(region: RectF, mode: RemoveMode) = TextRemover(
        videoW, videoH,
        (region.left * videoW).toInt(), (region.top * videoH).toInt(),
        (region.right * videoW).toInt(), (region.bottom * videoH).toInt(),
        strong = mode == RemoveMode.STRONG,
    )

    private fun startDecoder(input: File, r: TextRemover, startMs: Long?, durationSec: Double?): Engine.Running {
        val seek = if (startMs != null) listOf("-ss", sec(startMs)) else emptyList()
        val dur = if (durationSec != null) listOf("-t", durationSec.toString()) else emptyList()
        val dec = Engine.start(getApplication(), listOf("-nostdin") + seek + dur + listOf(
            "-i", input.absolutePath,
            "-vf", "fps=${fpsStr()},crop=${r.stripW}:${r.stripH}:${r.stripX}:${r.stripY}",
            "-an", "-f", "rawvideo", "-pix_fmt", "bgr24", "pipe:1",
        ))
        synchronized(running) { running += dec }
        return dec
    }

    private fun stopAll() = synchronized(running) {
        running.forEach { runCatching { it.destroy() } }
        running.clear()
    }

    private fun matToBitmap(bgr: Mat): Bitmap {
        val rgba = Mat()
        Imgproc.cvtColor(bgr, rgba, Imgproc.COLOR_BGR2RGBA)
        val bmp = Bitmap.createBitmap(bgr.cols(), bgr.rows(), Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(rgba, bmp)
        rgba.release()
        return bmp
    }

    /**
     * Modo rápido: delogo apaga a área preenchendo com os pixels das bordas e um
     * leve desfoque deixa a "emenda" menos visível.
     */
    private fun delogoFilter(region: RectF): String {
        val w0 = videoW; val h0 = videoH
        val x = (region.left * w0).toInt().coerceIn(2, w0 - 20)
        val y = (region.top * h0).toInt().coerceIn(2, h0 - 20)
        val w = (region.width() * w0).toInt().coerceIn(16, w0 - x - 2)
        val h = (region.height() * h0).toInt().coerceIn(16, h0 - y - 2)
        val blur = (minOf(w, h) / 8).coerceIn(2, 6)
        return "[0:v]delogo=x=$x:y=$y:w=$w:h=$h,split[m][r];" +
            "[r]crop=$w:$h:$x:$y,boxblur=$blur:1[b];" +
            "[m][b]overlay=$x:$y,format=yuv420p[v]"
    }

    private fun fpsStr() = String.format(Locale.US, "%.3f", fps)
    private fun sec(ms: Long) = String.format(Locale.US, "%.3f", ms / 1000.0)

    private fun formatEta(sec: Long): String =
        if (sec >= 60) "${sec / 60}min ${sec % 60}s" else "${sec}s"

    private suspend fun ensureLocalCopy(): File = copyLock.withLock {
        localCopy?.takeIf { it.exists() }?.let { return it }
        val u = uri ?: error("Nenhum vídeo aberto")
        _state.update { it.copy(status = "Copiando o vídeo…") }
        val ext = when (mime) {
            "video/webm" -> "webm"; "video/x-matroska" -> "mkv"; "video/quicktime" -> "mov"; else -> "mp4"
        }
        val f = File(work, "entrada.$ext")
        getApplication<Application>().contentResolver.openInputStream(u)?.use { input ->
            f.outputStream().use { input.copyTo(it, 256 * 1024) }
        } ?: error("Não consegui ler o arquivo")
        localCopy = f
        f
    }

    private fun save(file: File, treeUri: Uri, name: String): String {
        val ctx = getApplication<Application>()
        val dir = DocumentFile.fromTreeUri(ctx, treeUri) ?: error("Pasta inválida")
        val target = dir.createFile("video/mp4", name) ?: error("Não consegui criar o arquivo na pasta")
        ctx.contentResolver.openOutputStream(target.uri)?.use { out ->
            file.inputStream().use { it.copyTo(out, 256 * 1024) }
        } ?: error("Não consegui gravar o arquivo")
        return target.name ?: name
    }

    private fun grabFrame(mmr: MediaMetadataRetriever, posMs: Long): Bitmap? =
        mmr.getFrameAtTime(posMs * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
            ?: mmr.getFrameAtTime(0)

    private fun shrink(b: Bitmap): Bitmap {
        val max = 1280
        if (b.width <= max && b.height <= max) return b
        val s = max.toFloat() / maxOf(b.width, b.height)
        return Bitmap.createScaledBitmap(b, (b.width * s).toInt(), (b.height * s).toInt(), true)
    }

    private fun queryName(u: Uri): String? = runCatching {
        getApplication<Application>().contentResolver
            .query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
    }.getOrNull()

    private fun lastError(log: String): String =
        log.lines().map { it.trim() }.lastOrNull { it.isNotEmpty() && !it.startsWith("[") }?.take(200)
            ?: "erro desconhecido"

    override fun onCleared() {
        cancelled = true
        process?.destroy()
        stopAll()
        work.deleteRecursively()
    }
}
