package com.baixatudo.app

import android.content.Context
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import java.io.File
import kotlin.concurrent.thread

/**
 * Inicializa o yt-dlp/FFmpeg uma única vez e permite rodar o FFmpeg diretamente
 * (usado pelo removedor de legendas).
 */
object Engine {

    @Volatile private var ready = false

    @Synchronized
    fun init(ctx: Context) {
        if (ready) return
        val app = ctx.applicationContext
        YoutubeDL.getInstance().init(app)
        FFmpeg.getInstance().init(app)
        ready = true
    }

    class Result(val exitCode: Int, val log: String)

    /**
     * Executa o binário do FFmpeg que vem junto com a biblioteca.
     * [onStdout] recebe cada linha da saída padrão (usada para o progresso).
     * [onStart] entrega o Process para permitir cancelar.
     */
    fun ffmpeg(
        ctx: Context,
        args: List<String>,
        onStart: (Process) -> Unit = {},
        onStdout: (String) -> Unit = {},
    ): Result {
        init(ctx)
        val app = ctx.applicationContext
        val bin = File(app.applicationInfo.nativeLibraryDir, "libffmpeg.so")
        val packages = File(app.noBackupFilesDir, "youtubedl-android/packages")

        val pb = ProcessBuilder(listOf(bin.absolutePath, "-hide_banner", "-nostdin", "-y") + args)
        pb.environment().apply {
            this["LD_LIBRARY_PATH"] = listOf("ffmpeg", "python")
                .joinToString(":") { File(packages, "$it/usr/lib").absolutePath }
            this["TMPDIR"] = app.cacheDir.absolutePath
        }

        val process = pb.start()
        onStart(process)

        val log = StringBuilder()
        val errReader = thread(name = "ffmpeg-stderr") {
            process.errorStream.bufferedReader().forEachLine { line ->
                synchronized(log) {
                    log.appendLine(line)
                    if (log.length > 30_000) log.delete(0, log.length - 30_000)
                }
            }
        }
        process.inputStream.bufferedReader().forEachLine(onStdout)
        val code = process.waitFor()
        errReader.join()
        return Result(code, synchronized(log) { log.toString() })
    }
}
