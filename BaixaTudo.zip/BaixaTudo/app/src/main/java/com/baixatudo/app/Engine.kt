package com.baixatudo.app

import android.content.Context
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import org.opencv.android.OpenCVLoader
import java.io.File
import kotlin.concurrent.thread

/**
 * Inicializa yt-dlp, FFmpeg e OpenCV uma única vez e permite rodar o FFmpeg
 * diretamente (usado pelo removedor de legendas).
 */
object Engine {

    @Volatile private var ready = false

    @Synchronized
    fun init(ctx: Context) {
        if (ready) return
        val app = ctx.applicationContext
        YoutubeDL.getInstance().init(app)
        FFmpeg.getInstance().init(app)
        if (!OpenCVLoader.initLocal()) throw IllegalStateException("Falha ao carregar o OpenCV")
        ready = true
    }

    /** Um processo do FFmpeg em execução, com o log de erros sendo coletado. */
    class Running(val process: Process, private val errThread: Thread, private val log: StringBuilder) {
        fun waitFor(): Int {
            val code = process.waitFor()
            errThread.join(2000)
            return code
        }
        fun log(): String = synchronized(log) { log.toString() }
        fun destroy() = process.destroy()
    }

    /** Inicia o FFmpeg sem esperar terminar (stdin/stdout ficam livres para pipes). */
    fun start(ctx: Context, args: List<String>): Running {
        init(ctx)
        val app = ctx.applicationContext
        val bin = File(app.applicationInfo.nativeLibraryDir, "libffmpeg.so")
        val packages = File(app.noBackupFilesDir, "youtubedl-android/packages")

        val pb = ProcessBuilder(listOf(bin.absolutePath, "-hide_banner", "-y") + args)
        pb.environment().apply {
            this["LD_LIBRARY_PATH"] = listOf("ffmpeg", "python")
                .joinToString(":") { File(packages, "$it/usr/lib").absolutePath }
            this["TMPDIR"] = app.cacheDir.absolutePath
        }
        val process = pb.start()

        val log = StringBuilder()
        val errThread = thread(name = "ffmpeg-stderr") {
            runCatching {
                process.errorStream.bufferedReader().forEachLine { line ->
                    synchronized(log) {
                        log.appendLine(line)
                        if (log.length > 30_000) log.delete(0, log.length - 30_000)
                    }
                }
            }
        }
        return Running(process, errThread, log)
    }

    class Result(val exitCode: Int, val log: String)

    /**
     * Executa o FFmpeg até o fim. [onStdout] recebe cada linha da saída padrão
     * (usada para o progresso) e [onStart] entrega o Process para permitir cancelar.
     */
    fun ffmpeg(
        ctx: Context,
        args: List<String>,
        onStart: (Process) -> Unit = {},
        onStdout: (String) -> Unit = {},
    ): Result {
        val r = start(ctx, listOf("-nostdin") + args)
        onStart(r.process)
        r.process.inputStream.bufferedReader().forEachLine(onStdout)
        val code = r.waitFor()
        return Result(code, r.log())
    }
}
