package com.baixatudo.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.min

/**
 * Mostra um quadro do vídeo e um retângulo que o usuário arrasta e redimensiona
 * para marcar onde fica a legenda. A área é guardada normalizada (0..1).
 */
class RegionView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null,
) : View(context, attrs) {

    var bitmap: Bitmap? = null
        set(value) { field = value; invalidate() }

    /** Quando true, esconde o retângulo (usado na prévia do resultado). */
    var previewMode = false
        set(value) { field = value; invalidate() }

    /** Área marcada, em frações da largura/altura do vídeo. */
    val region = RectF(0.05f, 0.72f, 0.95f, 0.84f)

    var onRegionChanged: (() -> Unit)? = null

    private val dp = resources.displayMetrics.density
    private val img = RectF()
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val dim = Paint().apply { color = Color.argb(110, 0, 0, 0) }
    private val fill = Paint().apply { color = Color.argb(60, 229, 72, 77) }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(229, 72, 77); style = Paint.Style.STROKE; strokeWidth = 2.5f * dp
    }
    private val handle = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val handleBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(229, 72, 77); style = Paint.Style.STROKE; strokeWidth = 2.5f * dp
    }
    private val hint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 14 * dp; textAlign = Paint.Align.CENTER
        setShadowLayer(4 * dp, 0f, 0f, Color.BLACK)
    }

    fun setRegion(r: RectF) { region.set(r); invalidate() }

    override fun onDraw(canvas: Canvas) {
        val bmp = bitmap
        if (bmp == null) {
            canvas.drawText("Escolha um vídeo", width / 2f, height / 2f, hint)
            return
        }
        // Encaixa a imagem centralizada mantendo a proporção
        val scale = min(width.toFloat() / bmp.width, height.toFloat() / bmp.height)
        val w = bmp.width * scale; val h = bmp.height * scale
        img.set((width - w) / 2, (height - h) / 2, (width + w) / 2, (height + h) / 2)
        canvas.drawBitmap(bmp, null, img, bmpPaint)
        if (previewMode) return

        val r = toScreen()
        // Escurece fora da área para destacar o que será apagado
        val path = Path().apply {
            addRect(img, Path.Direction.CW)
            addRect(r, Path.Direction.CCW)
        }
        canvas.drawPath(path, dim)
        canvas.drawRect(r, fill)
        canvas.drawRect(r, stroke)
        val hr = 7 * dp
        for ((x, y) in corners(r)) {
            canvas.drawCircle(x, y, hr, handle)
            canvas.drawCircle(x, y, hr, handleBorder)
        }
    }

    private fun toScreen() = RectF(
        img.left + region.left * img.width(), img.top + region.top * img.height(),
        img.left + region.right * img.width(), img.top + region.bottom * img.height(),
    )

    private fun corners(r: RectF) = listOf(
        r.left to r.top, r.right to r.top, r.left to r.bottom, r.right to r.bottom,
    )

    // ------------------------------------------------------------ toque

    private enum class Mode { NONE, MOVE, TL, TR, BL, BR, TOP, BOTTOM, LEFT, RIGHT }
    private var mode = Mode.NONE
    private var lastX = 0f
    private var lastY = 0f

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (bitmap == null || previewMode || img.width() <= 0f) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                mode = hitTest(e.x, e.y)
                if (mode == Mode.NONE) return false
                parent?.requestDisallowInterceptTouchEvent(true)
                lastX = e.x; lastY = e.y
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = (e.x - lastX) / img.width()
                val dy = (e.y - lastY) / img.height()
                lastX = e.x; lastY = e.y
                applyDrag(dx, dy)
                invalidate()
                onRegionChanged?.invoke()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                mode = Mode.NONE
                return true
            }
        }
        return false
    }

    private fun hitTest(x: Float, y: Float): Mode {
        val r = toScreen()
        val touch = 28 * dp
        val c = corners(r)
        val near = { i: Int -> hypot(x - c[i].first, y - c[i].second) < touch }
        return when {
            near(0) -> Mode.TL
            near(1) -> Mode.TR
            near(2) -> Mode.BL
            near(3) -> Mode.BR
            x in r.left..r.right && abs(y - r.top) < touch / 2 -> Mode.TOP
            x in r.left..r.right && abs(y - r.bottom) < touch / 2 -> Mode.BOTTOM
            y in r.top..r.bottom && abs(x - r.left) < touch / 2 -> Mode.LEFT
            y in r.top..r.bottom && abs(x - r.right) < touch / 2 -> Mode.RIGHT
            r.contains(x, y) -> Mode.MOVE
            // Toque fora: puxa a área para lá
            img.contains(x, y) -> {
                val nx = (x - img.left) / img.width() - region.width() / 2
                val ny = (y - img.top) / img.height() - region.height() / 2
                region.offsetTo(nx.coerceIn(0f, 1f - region.width()), ny.coerceIn(0f, 1f - region.height()))
                invalidate(); onRegionChanged?.invoke()
                Mode.MOVE
            }
            else -> Mode.NONE
        }
    }

    private fun applyDrag(dx: Float, dy: Float) {
        val minSize = 0.03f
        val r = region
        when (mode) {
            Mode.MOVE -> {
                val nx = (r.left + dx).coerceIn(0f, 1f - r.width())
                val ny = (r.top + dy).coerceIn(0f, 1f - r.height())
                r.offsetTo(nx, ny)
            }
            Mode.TL -> { moveLeft(dx, minSize); moveTop(dy, minSize) }
            Mode.TR -> { moveRight(dx, minSize); moveTop(dy, minSize) }
            Mode.BL -> { moveLeft(dx, minSize); moveBottom(dy, minSize) }
            Mode.BR -> { moveRight(dx, minSize); moveBottom(dy, minSize) }
            Mode.TOP -> moveTop(dy, minSize)
            Mode.BOTTOM -> moveBottom(dy, minSize)
            Mode.LEFT -> moveLeft(dx, minSize)
            Mode.RIGHT -> moveRight(dx, minSize)
            Mode.NONE -> Unit
        }
    }

    private fun moveLeft(d: Float, m: Float) { region.left = (region.left + d).coerceIn(0f, region.right - m) }
    private fun moveRight(d: Float, m: Float) { region.right = (region.right + d).coerceIn(region.left + m, 1f) }
    private fun moveTop(d: Float, m: Float) { region.top = (region.top + d).coerceIn(0f, region.bottom - m) }
    private fun moveBottom(d: Float, m: Float) { region.bottom = (region.bottom + d).coerceIn(region.top + m, 1f) }
}
