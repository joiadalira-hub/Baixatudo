package com.baixatudo.app

import android.content.Intent
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Bundle
import android.view.Surface
import android.view.TextureView
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import com.baixatudo.app.databinding.ActivitySplashBinding

/**
 * Vinheta "Joia Games" (vídeo com som) sempre que o app é aberto do zero.
 * Ao voltar do minimizado o Android traz o app direto, sem passar por aqui.
 * Um toque na tela pula a vinheta.
 */
class SplashActivity : AppCompatActivity(), TextureView.SurfaceTextureListener {

    private lateinit var b: ActivitySplashBinding
    private var player: MediaPlayer? = null
    private var surface: Surface? = null
    private var done = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(b.root)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        b.splashVideo.surfaceTextureListener = this
        b.splashRoot.setOnClickListener { openApp() }
        // segurança: se algo travar, abre o app de qualquer jeito
        b.splashRoot.postDelayed({ openApp() }, 6000)
    }

    override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
        val s = Surface(st).also { surface = it }
        try {
            player = MediaPlayer().apply {
                setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE).build())
                val afd = resources.openRawResourceFd(R.raw.joia_intro)
                setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                afd.close()
                setSurface(s)
                setOnVideoSizeChangedListener { _, vw, vh -> centerCrop(vw, vh) }
                setOnCompletionListener { openApp() }
                setOnErrorListener { _, _, _ -> openApp(); true }
                setOnPreparedListener { it.start() }
                prepareAsync()
            }
        } catch (_: Exception) {
            openApp()
        }
    }

    /** Preenche a tela inteira sem distorcer (corta as sobras, que são só fundo). */
    private fun centerCrop(vw: Int, vh: Int) {
        val view = b.splashVideo
        val w = view.width.toFloat(); val h = view.height.toFloat()
        if (vw == 0 || vh == 0 || w == 0f || h == 0f) return
        val scale = maxOf(w / vw, h / vh)
        val m = Matrix()
        m.setScale(vw * scale / w, vh * scale / h, w / 2, h / 2)
        view.setTransform(m)
    }

    override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {
        player?.let { centerCrop(it.videoWidth, it.videoHeight) }
    }
    override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean = true
    override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}

    private var interrupted = false

    override fun onStop() {
        super.onStop()
        // saiu no meio da vinheta: para o som; na volta vai direto para o app
        if (!done) { release(); interrupted = true }
    }

    override fun onRestart() {
        super.onRestart()
        if (interrupted) openApp()
    }

    private fun release() {
        player?.runCatching { stop(); release() }
        player = null
        surface?.release(); surface = null
    }

    private fun openApp() {
        if (done || isFinishing) return
        done = true
        release()
        startActivity(Intent(this, MainActivity::class.java))
        @Suppress("DEPRECATION")
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }

    override fun onDestroy() {
        release()
        super.onDestroy()
    }
}
