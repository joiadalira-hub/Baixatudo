package com.baixatudo.app

import android.animation.ValueAnimator
import android.content.Intent
import android.graphics.LinearGradient
import android.graphics.Shader
import android.os.Bundle
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import androidx.appcompat.app.AppCompatActivity
import com.baixatudo.app.databinding.ActivitySplashBinding

/** Abertura de ~2 s com a marca "Joia Games" e depois abre o app. */
class SplashActivity : AppCompatActivity() {

    private lateinit var b: ActivitySplashBinding
    private var done = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(b.root)

        // "JOIA" com o gradiente rosa -> ciano da identidade
        b.splashJoia.post {
            val w = b.splashJoia.paint.measureText("JOIA")
            b.splashJoia.paint.shader = LinearGradient(0f, 0f, w, 0f,
                intArrayOf(0xFFFF6BE6.toInt(), 0xFFE7B8FF.toInt(), 0xFF2EE6FF.toInt()),
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
            b.splashJoia.invalidate()
        }

        // 1) diamante surge girando e "quica"
        b.splashDiamond.apply {
            scaleX = 0.3f; scaleY = 0.3f; rotation = -25f; translationY = 40f
            animate().alpha(1f).scaleX(1f).scaleY(1f).rotation(0f).translationY(0f)
                .setDuration(650).setInterpolator(OvershootInterpolator(1.6f)).start()
        }
        // 2) "JOIA" sobe
        b.splashJoia.apply {
            translationY = 60f
            animate().alpha(1f).translationY(0f).setStartDelay(350)
                .setDuration(500).setInterpolator(DecelerateInterpolator()).start()
        }
        // 3) linha se abre e "GAMES" aparece espaçando as letras
        b.splashLine.animate().scaleX(1f).setStartDelay(700).setDuration(450)
            .setInterpolator(DecelerateInterpolator()).start()
        b.splashGames.apply {
            letterSpacing = 1.2f
            animate().alpha(1f).setStartDelay(800).setDuration(500).start()
            ValueAnimator.ofFloat(1.2f, 0.65f).apply {
                startDelay = 800; duration = 600
                interpolator = DecelerateInterpolator()
                addUpdateListener { letterSpacing = it.animatedValue as Float }
            }.start()
        }
        // 4) brilho pulsando no diamante
        ValueAnimator.ofFloat(1f, 1.07f, 1f).apply {
            startDelay = 1100; duration = 600
            addUpdateListener {
                val s = it.animatedValue as Float
                b.splashDiamond.scaleX = s; b.splashDiamond.scaleY = s
            }
        }.start()
        // 5) some e abre o app
        b.splashRoot.postDelayed({
            b.splashRoot.animate().alpha(0f).setDuration(250).withEndAction { openApp() }.start()
        }, 1750)
    }

    private fun openApp() {
        if (done || isFinishing) return
        done = true
        startActivity(Intent(this, MainActivity::class.java))
        @Suppress("DEPRECATION")
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }
}
