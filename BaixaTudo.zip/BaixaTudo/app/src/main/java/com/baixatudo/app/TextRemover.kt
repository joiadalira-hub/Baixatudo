package com.baixatudo.app

import org.opencv.calib3d.Calib3d
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.MatOfByte
import org.opencv.core.MatOfFloat
import org.opencv.core.MatOfPoint
import org.opencv.core.MatOfPoint2f
import org.opencv.core.Point
import org.opencv.core.Rect
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import org.opencv.photo.Photo
import org.opencv.video.Video
import java.io.DataInputStream
import java.io.EOFException
import java.io.InputStream
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Remoção "precisa" de legendas:
 *
 *  1. Dentro da área marcada, detecta só os pixels das letras (miolo + contorno),
 *     em vez de apagar o retângulo inteiro.
 *  2. Rastreia o movimento da câmera/fundo entre os quadros (optical flow) e copia
 *     o fundo VERDADEIRO de quadros vizinhos em que aquele ponto não estava coberto.
 *  3. O quadro anterior já limpo também é reaproveitado, então o fundo recuperado
 *     vai sendo carregado para frente.
 *  4. Só o que não aparece em lugar nenhum é reconstruído por inpainting (Telea).
 *
 * Lê só uma faixa em volta da área (o resto do vídeo não é tocado) e faz o trabalho
 * pesado só dentro da área marcada.
 */
class TextRemover(
    frameW: Int,
    frameH: Int,
    boxLeft: Int, boxTop: Int, boxRight: Int, boxBottom: Int,
    private val strong: Boolean,
) {
    // Caixa marcada pelo usuário (coordenadas do vídeo)
    private val bx0 = boxLeft.coerceIn(0, frameW - 8)
    private val by0 = boxTop.coerceIn(0, frameH - 8)
    private val bx1 = boxRight.coerceIn(bx0 + 8, frameW)
    private val by1 = boxBottom.coerceIn(by0 + 8, frameH)
    private val boxH = by1 - by0

    // Faixa lida do vídeo = caixa + margem (a margem serve para rastrear o movimento).
    // Tudo PAR: o FFmpeg arredonda recortes ímpares em vídeos yuv420p.
    private val margin = max(40, boxH)
    val stripX = max(0, bx0 - margin) and 1.inv()
    val stripY = max(0, by0 - margin) and 1.inv()
    val stripW = (min(frameW, bx1 + margin) - stripX) and 1.inv()
    val stripH = (min(frameH, by1 + margin) - stripY) and 1.inv()

    // Área de trabalho = caixa + uma pequena borda (coordenadas da faixa)
    private val work: Rect = run {
        val pad = 12
        val x0 = max(0, bx0 - stripX - pad); val y0 = max(0, by0 - stripY - pad)
        val x1 = min(stripW, bx1 - stripX + pad); val y1 = min(stripH, by1 - stripY + pad)
        Rect(x0, y0, x1 - x0, y1 - y0)
    }
    /** A caixa do usuário dentro da área de trabalho */
    private val boxInWork = Rect(
        max(0, bx0 - stripX - work.x), max(0, by0 - stripY - work.y),
        min(bx1 - bx0, work.width), min(by1 - by0, work.height),
    ).let { r -> Rect(r.x, r.y, min(r.width, work.width - r.x), min(r.height, work.height - r.y)) }

    private val stripSize = Size(stripW.toDouble(), stripH.toDouble())
    private val workSize = Size(work.width.toDouble(), work.height.toDouble())
    private val halfSize = Size((stripW / 2).toDouble(), (stripH / 2).toDouble())
    private val frameBytes = stripW * stripH * 3

    // Quantos quadros para frente/para trás guardar (limitado pela memória)
    private val window: Int = run {
        val perFrame = frameBytes + stripW * stripH + stripW * stripH / 4L + work.area().toLong()
        ((260L * 1024 * 1024) / perFrame / 2).toInt().coerceIn(6, 30)
    }
    /** Vizinhos consultados: perto com densidade, longe espaçado (mais rápido) */
    private val offsets = intArrayOf(1, 2, 3, 4, 5, 6, 8, 10, 12, 15, 18, 22, 26, 30).filter { it <= window }

    // Parâmetros da detecção de letras
    private val threshold = if (strong) 24.0 else 40.0
    private val morphK = ((boxH * 0.45).toInt().coerceIn(9, 61)) or 1
    private val dilateK = (max(5, frameH / 180) + if (strong) 4 else 0) or 1
    private val inpaintRadius = (frameH / 180.0).coerceIn(4.0, 10.0)

    // Estabilidade: legenda fica PARADA na tela; o que se mexe (pessoa, fundo) não é letra
    private val stabFrames = 3
    private val stabMaxDiff = 14.0
    // Verificação de consistência das cópias (feita em 1/4 da resolução)
    private val checkSigma = max(6.0, frameH / 64.0) / 4.0
    private val checkMaxErr = 10.0
    private val checkMinWeight = 0.002

    private fun ellipse(k: Int) = Imgproc.getStructuringElement(Imgproc.MORPH_ELLIPSE, Size(k.toDouble(), k.toDouble()))
    private val morphKernel = ellipse(morphK)
    private val nearKernel = ellipse(dilateK)
    private val aroundKernel = ellipse((3 * dilateK) or 1)
    private val dilateKernel = ellipse(dilateK)
    private val openKernel = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(2.0, 2.0))
    private val k3 = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(3.0, 3.0))
    private val stabOpen = ellipse(3)
    private val stabClose = ellipse(7)

    /** Onde procurar pontos para rastrear (meia resolução): tudo menos a caixa. */
    private val trackMask = Mat(stripH / 2, stripW / 2, CvType.CV_8U, Scalar(255.0)).also {
        val x = (bx0 - stripX) / 2; val y = (by0 - stripY) / 2
        val w = min((bx1 - bx0) / 2 + 1, it.cols() - x); val h = min((by1 - by0) / 2 + 1, it.rows() - y)
        if (w > 0 && h > 0) it.submat(Rect(x, y, w, h)).setTo(Scalar(0.0))
    }
    private val ones = Mat(stripH, stripW, CvType.CV_8U, Scalar(255.0))

    // Mats temporários reaproveitados (evita alocar megabytes a cada quadro)
    private val tWarped = Mat(); private val tValid = Mat(); private val tUse = Mat()
    private val tM = Mat(2, 3, CvType.CV_64F)
    // temporários da verificação de consistência
    private val curNotMask = Mat(); private val curGrayF = Mat()
    private val cRing = Mat(); private val cRingF = Mat(); private val cWarpGray = Mat()
    private val cWarpF = Mat(); private val cCurF = Mat(); private val cBad = Mat()
    private val qRing = Mat(); private val qWarp = Mat(); private val qCur = Mat(); private val qErr = Mat()
    private val qTmp = Mat(); private val qW = Mat(); private val qNum = Mat(); private val qDen = Mat()
    private val qBad = Mat(); private val qBad2 = Mat()
    private val quarter = Size(max(1, work.width / 4).toDouble(), max(1, work.height / 4).toDouble())

    /**
     * [raw] = pixels com cara de letra; [mask] = máscara usada (provisória até a
     * estabilidade ser checada); [notMask] = inverso da máscara na faixa inteira.
     */
    private class Frame(val bgr: Mat, val half: Mat, val workGray: Mat, val raw: Mat,
                        var mask: Mat, var notMask: Mat, var finalized: Boolean = false) {
        fun release() { listOf(bgr, half, workGray, raw, mask, notMask).forEach { it.release() } }
    }

    private val frames = HashMap<Int, Frame>()
    /** steps[i] = transformação afim que leva coordenadas do quadro i para o quadro i+1 */
    private val steps = HashMap<Int, DoubleArray?>()

    /**
     * Lê quadros BGR24 da faixa (stripW x stripH) de [input], processa e entrega cada
     * quadro limpo em [onFrame] (o Mat só vale durante a chamada).
     * [onBuffering] avisa quantos quadros já foram lidos antes do primeiro sair.
     */
    fun run(
        input: InputStream,
        onFrame: (index: Int, frame: Mat) -> Unit,
        isCancelled: () -> Boolean,
        onBuffering: (Int) -> Unit = {},
    ) {
        val data = DataInputStream(input.buffered(1 shl 20))
        val buf = ByteArray(frameBytes)
        var read = 0
        var eof = false
        var prevOut: Mat? = null
        var t = 0
        var flushed = false

        try {
            while (!isCancelled()) {
                // Mantém [window] quadros de antecedência carregados
                while (!eof && read <= t + window && !isCancelled()) {
                    try {
                        data.readFully(buf)
                    } catch (_: EOFException) {
                        eof = true
                        break
                    }
                    addFrame(read, buf)
                    read++
                    if (t == 0) onBuffering(read)
                }
                if (eof && !flushed) {
                    for (i in max(0, read - stabFrames) until read) finalize(i)
                    flushed = true
                }
                if (t >= read || isCancelled()) break

                val out = processFrame(t, prevOut)
                onFrame(t, out)
                prevOut?.release()
                prevOut = out

                frames.remove(t - window)?.release()
                steps.remove(t - window - 1)
                t++
            }
        } finally {
            prevOut?.release()
            frames.values.forEach { it.release() }
            frames.clear(); steps.clear()
        }
    }

    fun release() {
        listOf(morphKernel, nearKernel, aroundKernel, dilateKernel, openKernel, k3, stabOpen, stabClose,
            trackMask, ones, tWarped, tValid, tUse, tM,
            curNotMask, curGrayF, cRing, cRingF, cWarpGray, cWarpF, cCurF, cBad,
            qRing, qWarp, qCur, qErr, qTmp, qW, qNum, qDen, qBad, qBad2).forEach { it.release() }
    }

    // ------------------------------------------------------------------ etapas

    private fun addFrame(index: Int, bytes: ByteArray) {
        val bgr = Mat(stripH, stripW, CvType.CV_8UC3)
        bgr.put(0, 0, bytes)
        val gray = Mat()
        Imgproc.cvtColor(bgr, gray, Imgproc.COLOR_BGR2GRAY)
        val half = Mat()
        Imgproc.resize(gray, half, halfSize, 0.0, 0.0, Imgproc.INTER_AREA)
        val workGray = gray.submat(work).clone()
        gray.release()

        val raw = detectText(workGray)
        // Máscara provisória (conservadora) até sabermos o que está parado na tela
        val mask = Mat()
        Imgproc.dilate(raw, mask, dilateKernel)

        frames[index - 1]?.let { prev -> steps[index - 1] = estimateMotion(prev.half, half) }
        frames[index] = Frame(bgr, half, workGray, raw, mask, notMaskOf(mask))
        finalize(index - stabFrames)
    }

    private fun notMaskOf(mask: Mat): Mat {
        val notMask = Mat(stripH, stripW, CvType.CV_8U, Scalar(255.0))
        val sub = notMask.submat(work)
        Core.bitwise_not(mask, sub)
        sub.release()
        return notMask
    }

    /**
     * Máscara final do quadro i: só o que tem cara de letra E ficou parado na tela
     * nos quadros de antes OU nos de depois (a legenda é fixa; a pessoa se mexe).
     */
    private fun finalize(i: Int) {
        val f = frames[i] ?: return
        if (f.finalized) return
        fun maxDiff(range: IntRange): Mat? {
            var acc: Mat? = null
            val d = Mat()
            for (n in range) {
                val g = frames[n]?.workGray ?: continue
                Core.absdiff(g, f.workGray, d)
                val a = acc
                if (a == null) acc = d.clone() else Core.max(a, d, a)
            }
            d.release()
            return acc
        }
        val past = maxDiff((i - stabFrames) until i)
        val future = maxDiff((i + 1)..(i + stabFrames))
        val md: Mat
        if (past != null && future != null) {
            Core.min(past, future, past); future.release(); md = past
        } else if (past != null) {
            md = past
        } else if (future != null) {
            md = future
        } else {
            return
        }
        val stable = Mat()
        Imgproc.threshold(md, stable, stabMaxDiff, 255.0, Imgproc.THRESH_BINARY_INV)
        md.release()

        val m = Mat()
        Core.bitwise_and(f.raw, stable, m)
        stable.release()
        Imgproc.morphologyEx(m, m, Imgproc.MORPH_OPEN, stabOpen)    // tira pontinhos soltos
        Imgproc.morphologyEx(m, m, Imgproc.MORPH_CLOSE, stabClose)  // fecha buracos nas letras
        Imgproc.dilate(m, m, dilateKernel)                          // borda/antialias

        f.mask.release(); f.notMask.release()
        f.mask = m
        f.notMask = notMaskOf(m)
        f.finalized = true
    }

    /** Detecta as letras dentro da área de trabalho. */
    private fun detectText(gray: Mat): Mat {
        val top = Mat(); val blk = Mat(); val bright = Mat(); val dark = Mat(); val m = Mat()
        Imgproc.morphologyEx(gray, top, Imgproc.MORPH_TOPHAT, morphKernel)
        Imgproc.morphologyEx(gray, blk, Imgproc.MORPH_BLACKHAT, morphKernel)
        Imgproc.threshold(top, bright, threshold, 255.0, Imgproc.THRESH_BINARY)
        Imgproc.threshold(blk, dark, threshold, 255.0, Imgproc.THRESH_BINARY)

        if (strong) {
            // Forte: qualquer coisa clara ou escura de alto contraste
            Core.bitwise_or(bright, dark, m)
            Imgproc.morphologyEx(m, m, Imgproc.MORPH_OPEN, openKernel)
        } else {
            // Precisa: miolo claro encostado num contorno escuro (padrão de legenda)
            val near = Mat()
            Imgproc.dilate(dark, near, nearKernel)
            Core.bitwise_and(bright, near, m)
            near.release()
            Imgproc.morphologyEx(m, m, Imgproc.MORPH_OPEN, openKernel)
            reconstruct(m, bright)          // completa o miolo inteiro das letras
            // engloba o contorno/sombra em volta das letras
            val around = Mat(); val either = Mat()
            Imgproc.dilate(m, around, aroundKernel)
            Core.bitwise_or(bright, dark, either)
            Core.bitwise_and(around, either, around)
            Core.bitwise_or(m, around, m)
            around.release(); either.release()
        }

        // Só dentro da caixa do usuário
        val out = Mat.zeros(work.height, work.width, CvType.CV_8U)
        val src = m.submat(boxInWork); val dst = out.submat(boxInWork)
        src.copyTo(dst)
        listOf(src, dst, top, blk, bright, dark, m).forEach { it.release() }
        return out
    }

    /** Reconstrução morfológica: cresce [seed] só por dentro de [limit]. */
    private fun reconstruct(seed: Mat, limit: Mat) {
        val next = Mat(); val diff = Mat()
        try {
            repeat(6) {
                Imgproc.dilate(seed, next, k3, Point(-1.0, -1.0), 2)
                Core.bitwise_and(next, limit, next)
                Core.absdiff(next, seed, diff)
                val changed = Core.countNonZero(diff) > 0
                next.copyTo(seed)
                if (!changed) return
            }
        } finally {
            next.release(); diff.release()
        }
    }

    /** Movimento do quadro a para o b, estimado em meia resolução. */
    private fun estimateMotion(a: Mat, b: Mat): DoubleArray? {
        val corners = MatOfPoint()
        val p0 = MatOfPoint2f(); val p1 = MatOfPoint2f()
        val status = MatOfByte(); val err = MatOfFloat()
        val from = MatOfPoint2f(); val to = MatOfPoint2f()
        val inliers = Mat()
        try {
            Imgproc.goodFeaturesToTrack(a, corners, 200, 0.01, 5.0, trackMask)
            val pts = corners.toArray()
            if (pts.size < 8) return null
            p0.fromArray(*pts)
            Video.calcOpticalFlowPyrLK(a, b, p0, p1, status, err, Size(15.0, 15.0), 3)

            val st = status.toArray(); val src = p0.toArray(); val dst = p1.toArray()
            val f = ArrayList<Point>(); val g = ArrayList<Point>()
            for (i in st.indices) if (st[i].toInt() == 1) { f += src[i]; g += dst[i] }
            if (f.size < 8) return null
            from.fromList(f); to.fromList(g)

            val m = Calib3d.estimateAffinePartial2D(from, to, inliers, Calib3d.RANSAC, 1.0)
            if (m.empty() || Core.countNonZero(inliers) < 8) { m.release(); return null }
            val d = DoubleArray(6)
            m.get(0, 0, d)
            m.release()
            d[2] *= 2.0; d[5] *= 2.0          // volta para a resolução cheia
            return d
        } catch (_: Exception) {
            return null
        } finally {
            listOf(corners, p0, p1, status, err, from, to, inliers).forEach { it.release() }
        }
    }

    private fun processFrame(t: Int, prevOut: Mat?): Mat {
        val f = frames.getValue(t)
        val out = f.bgr.clone()
        val outW = out.submat(work)
        val rem = f.mask.clone()
        // Referência para checar as cópias: o quadro atual, fora das letras
        Core.bitwise_not(f.mask, curNotMask)
        f.workGray.convertTo(curGrayF, CvType.CV_32F)
        try {
            val total = Core.countNonZero(rem)
            if (total == 0) return out
            val tiny = total / 500

            // 1) Fundo real dos vizinhos, do mais próximo para o mais distante
            var left = total
            for (k in offsets) {
                for (n in intArrayOf(t + k, t - k)) {
                    val nf = frames[n] ?: continue
                    val tr = transform(t, n) ?: continue
                    fill(outW, rem, nf.bgr, nf.notMask, tr)
                }
                left = Core.countNonZero(rem)
                if (left <= tiny) break
            }
            // 2) Quadro anterior já limpo (carrega o fundo recuperado para frente)
            if (left > tiny && prevOut != null) {
                transform(t, t - 1)?.let { fill(outW, rem, prevOut, ones, it) }
                left = Core.countNonZero(rem)
            }
            // 3) O que sobrou: reconstrói a partir das bordas
            if (left > 0) {
                val dst = Mat()
                Photo.inpaint(outW, rem, dst, inpaintRadius, Photo.INPAINT_TELEA)
                dst.copyTo(outW)
                dst.release()
            }
            return out
        } finally {
            outW.release()
            rem.release()
        }
    }

    /**
     * Copia para a área de trabalho [outW] os pixels do quadro vizinho [src] (faixa inteira,
     * alinhado por [tr]) onde ainda falta ([rem]) e onde o vizinho é limpo ([srcValid]).
     */
    private fun fill(outW: Mat, rem: Mat, src: Mat, srcValid: Mat, tr: DoubleArray) {
        // destino (u,v) da área de trabalho = (u + work.x, v + work.y) na faixa -> vizinho
        val wx = work.x.toDouble(); val wy = work.y.toDouble()
        tM.put(0, 0,
            tr[0], tr[1], tr[0] * wx + tr[1] * wy + tr[2],
            tr[3], tr[4], tr[3] * wx + tr[4] * wy + tr[5])
        val inv = Imgproc.WARP_INVERSE_MAP
        Imgproc.warpAffine(src, tWarped, tM, workSize, Imgproc.INTER_LINEAR or inv, Core.BORDER_CONSTANT, Scalar(0.0, 0.0, 0.0))
        Imgproc.warpAffine(srcValid, tValid, tM, workSize, Imgproc.INTER_NEAREST or inv, Core.BORDER_CONSTANT, Scalar(0.0))
        Core.bitwise_and(rem, tValid, tUse)
        if (Core.countNonZero(tUse) == 0) return
        rejectInconsistent()
        tWarped.copyTo(outW, tUse)
        Core.subtract(rem, tUse, rem)
    }

    /**
     * Compara a cópia com o quadro atual em volta das letras (onde os dois são visíveis).
     * Onde não bate — a pessoa se mexeu, o fundo não acompanha a câmera — a cópia é
     * descartada. Isso é o que evita os "fantasmas". Feito em 1/4 da resolução.
     */
    private fun rejectInconsistent() {
        // ring = visível no quadro atual E no vizinho
        Core.bitwise_and(curNotMask, tValid, cRing)
        cRing.convertTo(cRingF, CvType.CV_32F, 1.0 / 255.0)
        Imgproc.cvtColor(tWarped, cWarpGray, Imgproc.COLOR_BGR2GRAY)
        cWarpGray.convertTo(cWarpF, CvType.CV_32F)
        Core.multiply(cWarpF, cRingF, cWarpF)
        Core.multiply(curGrayF, cRingF, cCurF)

        // médias só sobre os pixels visíveis de cada bloquinho
        Imgproc.resize(cRingF, qRing, quarter, 0.0, 0.0, Imgproc.INTER_AREA)
        Imgproc.resize(cWarpF, qWarp, quarter, 0.0, 0.0, Imgproc.INTER_AREA)
        Imgproc.resize(cCurF, qCur, quarter, 0.0, 0.0, Imgproc.INTER_AREA)
        Core.absdiff(qWarp, qCur, qErr)
        Core.max(qRing, Scalar(1e-3), qTmp)
        Core.divide(qErr, qTmp, qErr)

        // espalha o erro para dentro das letras (convolução normalizada)
        Imgproc.threshold(qRing, qW, 0.25, 1.0, Imgproc.THRESH_BINARY)
        Core.multiply(qErr, qW, qErr)
        Imgproc.GaussianBlur(qErr, qNum, Size(0.0, 0.0), checkSigma)
        Imgproc.GaussianBlur(qW, qDen, Size(0.0, 0.0), checkSigma)
        Core.max(qDen, Scalar(1e-4), qTmp)
        Core.divide(qNum, qTmp, qErr)

        Core.compare(qErr, Scalar(checkMaxErr), qBad, Core.CMP_GT)
        Core.compare(qDen, Scalar(checkMinWeight), qBad2, Core.CMP_GT)
        Core.bitwise_and(qBad, qBad2, qBad)
        Imgproc.resize(qBad, cBad, workSize, 0.0, 0.0, Imgproc.INTER_NEAREST)
        Core.bitwise_not(cBad, cBad)
        Core.bitwise_and(tUse, cBad, tUse)
    }

    /** Transformação que leva coordenadas do quadro t para o quadro n (encadeando os passos). */
    private fun transform(t: Int, n: Int): DoubleArray? {
        var tr = IDENTITY
        if (n > t) {
            for (i in t until n) tr = compose(steps[i] ?: return null, tr)
        } else {
            for (i in t - 1 downTo n) tr = compose(invert(steps[i] ?: return null) ?: return null, tr)
        }
        return tr
    }

    companion object {
        private val IDENTITY = doubleArrayOf(1.0, 0.0, 0.0, 0.0, 1.0, 0.0)

        /** b ∘ a  (aplica a, depois b) — matrizes afins 2x3 em linha */
        private fun compose(b: DoubleArray, a: DoubleArray) = doubleArrayOf(
            b[0] * a[0] + b[1] * a[3], b[0] * a[1] + b[1] * a[4], b[0] * a[2] + b[1] * a[5] + b[2],
            b[3] * a[0] + b[4] * a[3], b[3] * a[1] + b[4] * a[4], b[3] * a[2] + b[4] * a[5] + b[5],
        )

        private fun invert(m: DoubleArray): DoubleArray? {
            val det = m[0] * m[4] - m[1] * m[3]
            if (abs(det) < 1e-9) return null
            val i0 = m[4] / det; val i1 = -m[1] / det
            val i3 = -m[3] / det; val i4 = m[0] / det
            return doubleArrayOf(i0, i1, -(i0 * m[2] + i1 * m[5]), i3, i4, -(i3 * m[2] + i4 * m[5]))
        }
    }
}
