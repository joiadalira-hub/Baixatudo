package com.baixatudo.app

import org.opencv.calib3d.Calib3d
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.MatOfByte
import org.opencv.core.MatOfFloat
import org.opencv.core.MatOfPoint
import org.opencv.core.MatOfPoint2f
import org.opencv.core.Point
import org.opencv.core.Rect
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import org.opencv.photo.Photo
import org.opencv.video.Video
import java.io.DataInputStream
import java.io.EOFException
import java.io.InputStream
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Remoção "precisa" de legendas:
 *
 *  1. Dentro da área marcada, detecta só os pixels das letras (e o contorno),
 *     em vez de apagar o retângulo inteiro.
 *  2. Rastreia o movimento da câmera/fundo entre os quadros (optical flow) e copia
 *     o fundo VERDADEIRO de quadros vizinhos em que aquele ponto não estava coberto.
 *  3. O quadro anterior já limpo também é reaproveitado, então o fundo recuperado
 *     vai sendo carregado para frente.
 *  4. Só o que não aparece em lugar nenhum é reconstruído por inpainting (Telea).
 *
 * Trabalha apenas numa faixa em volta da área marcada (o resto do vídeo não é tocado).
 */
class TextRemover(
    frameW: Int,
    frameH: Int,
    boxLeft: Int, boxTop: Int, boxRight: Int, boxBottom: Int,
    strong: Boolean,
) {
    // Caixa marcada pelo usuário (coordenadas do vídeo)
    private val bx0 = boxLeft.coerceIn(0, frameW - 8)
    private val by0 = boxTop.coerceIn(0, frameH - 8)
    private val bx1 = boxRight.coerceIn(bx0 + 8, frameW)
    private val by1 = boxBottom.coerceIn(by0 + 8, frameH)
    private val boxH = by1 - by0

    // Faixa processada = caixa + margem (a margem serve para rastrear o movimento)
    private val margin = max(40, boxH)
    val stripX = max(0, bx0 - margin)
    val stripY = max(0, by0 - margin)
    val stripW = min(frameW, bx1 + margin) - stripX
    val stripH = min(frameH, by1 + margin) - stripY

    private val roi = Rect(bx0 - stripX, by0 - stripY, bx1 - bx0, by1 - by0)
    private val size = Size(stripW.toDouble(), stripH.toDouble())
    private val frameBytes = stripW * stripH * 3

    // Quantos quadros para frente/para trás procurar o fundo (limitado pela memória)
    private val window: Int = run {
        val perFrame = frameBytes + stripW * stripH * 3L   // bgr + gray + 2 máscaras
        ((260L * 1024 * 1024) / perFrame / 2).toInt().coerceIn(6, 30)
    }

    // Parâmetros da detecção de letras
    private val threshold = if (strong) 24.0 else 40.0
    private val morphK = ((boxH * 0.45).toInt().coerceIn(9, 61)) or 1
    private val dilateK = (max(5, frameH / 180) + if (strong) 4 else 0) or 1
    private val inpaintRadius = (frameH / 180.0).coerceIn(4.0, 10.0)

    private val morphKernel = Imgproc.getStructuringElement(Imgproc.MORPH_ELLIPSE, Size(morphK.toDouble(), morphK.toDouble()))
    private val openKernel = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(2.0, 2.0))
    private val dilateKernel = Imgproc.getStructuringElement(Imgproc.MORPH_ELLIPSE, Size(dilateK.toDouble(), dilateK.toDouble()))

    /** Onde procurar pontos para rastrear: tudo da faixa menos a caixa (onde está o texto). */
    private val trackMask = Mat(stripH, stripW, CvType.CV_8U, Scalar(255.0)).also {
        it.submat(roi).setTo(Scalar(0.0))
    }
    private val ones = Mat(stripH, stripW, CvType.CV_8U, Scalar(255.0))

    private class Frame(val bgr: Mat, val gray: Mat, val mask: Mat, val notMask: Mat) {
        fun release() { bgr.release(); gray.release(); mask.release(); notMask.release() }
    }

    private val frames = HashMap<Int, Frame>()
    /** steps[i] = transformação afim que leva coordenadas do quadro i para o quadro i+1 */
    private val steps = HashMap<Int, DoubleArray?>()

    /**
     * Lê quadros BGR24 da faixa (stripW x stripH) de [input], processa e entrega cada
     * quadro limpo em [onFrame] (o Mat só vale durante a chamada).
     */
    fun run(
        input: InputStream,
        onFrame: (index: Int, frame: Mat) -> Unit,
        isCancelled: () -> Boolean,
    ) {
        val data = DataInputStream(input.buffered(1 shl 20))
        val buf = ByteArray(frameBytes)
        var read = 0
        var eof = false
        var prevOut: Mat? = null
        var t = 0

        try {
            while (!isCancelled()) {
                // Mantém [window] quadros de antecedência carregados
                while (!eof && read <= t + window) {
                    try {
                        data.readFully(buf)
                    } catch (_: EOFException) {
                        eof = true
                        break
                    }
                    addFrame(read, buf)
                    read++
                }
                if (t >= read) break

                val out = processFrame(t, prevOut)
                onFrame(t, out)
                prevOut?.release()
                prevOut = out

                frames.remove(t - window)?.release()
                steps.remove(t - window - 1)
                t++
            }
        } finally {
            prevOut?.release()
            frames.values.forEach { it.release() }
            frames.clear(); steps.clear()
        }
    }

    fun release() {
        morphKernel.release(); openKernel.release(); dilateKernel.release()
        trackMask.release(); ones.release()
    }

    // ------------------------------------------------------------------ etapas

    private fun addFrame(index: Int, bytes: ByteArray) {
        val bgr = Mat(stripH, stripW, CvType.CV_8UC3)
        bgr.put(0, 0, bytes)
        val gray = Mat()
        Imgproc.cvtColor(bgr, gray, Imgproc.COLOR_BGR2GRAY)
        val mask = detectText(gray)
        val notMask = Mat()
        Core.bitwise_not(mask, notMask)
        frames[index - 1]?.let { prev -> steps[index - 1] = estimateMotion(prev.gray, gray) }
        frames[index] = Frame(bgr, gray, mask, notMask)
    }

    /** Letras claras (top-hat) ou escuras/contorno (black-hat), engrossadas para pegar a borda. */
    private fun detectText(gray: Mat): Mat {
        val top = Mat(); val blk = Mat(); val m1 = Mat(); val m2 = Mat(); val m = Mat()
        Imgproc.morphologyEx(gray, top, Imgproc.MORPH_TOPHAT, morphKernel)
        Imgproc.morphologyEx(gray, blk, Imgproc.MORPH_BLACKHAT, morphKernel)
        Imgproc.threshold(top, m1, threshold, 255.0, Imgproc.THRESH_BINARY)
        Imgproc.threshold(blk, m2, threshold, 255.0, Imgproc.THRESH_BINARY)
        Core.bitwise_or(m1, m2, m)
        Imgproc.morphologyEx(m, m, Imgproc.MORPH_OPEN, openKernel)
        Imgproc.dilate(m, m, dilateKernel)

        val out = Mat.zeros(stripH, stripW, CvType.CV_8U)
        m.submat(roi).copyTo(out.submat(roi))
        listOf(top, blk, m1, m2, m).forEach { it.release() }
        return out
    }

    private fun estimateMotion(a: Mat, b: Mat): DoubleArray? {
        val corners = MatOfPoint()
        val p0 = MatOfPoint2f(); val p1 = MatOfPoint2f()
        val status = MatOfByte(); val err = MatOfFloat()
        val from = MatOfPoint2f(); val to = MatOfPoint2f()
        val inliers = Mat()
        try {
            Imgproc.goodFeaturesToTrack(a, corners, 300, 0.01, 7.0, trackMask)
            val pts = corners.toArray()
            if (pts.size < 8) return null
            p0.fromArray(*pts)
            Video.calcOpticalFlowPyrLK(a, b, p0, p1, status, err, Size(21.0, 21.0), 3)

            val st = status.toArray(); val src = p0.toArray(); val dst = p1.toArray()
            val f = ArrayList<Point>(); val g = ArrayList<Point>()
            for (i in st.indices) if (st[i].toInt() == 1) { f += src[i]; g += dst[i] }
            if (f.size < 8) return null
            from.fromList(f); to.fromList(g)

            val m = Calib3d.estimateAffinePartial2D(from, to, inliers, Calib3d.RANSAC, 2.0)
            if (m.empty() || Core.countNonZero(inliers) < 8) { m.release(); return null }
            val d = DoubleArray(6)
            m.get(0, 0, d)
            m.release()
            return d
        } catch (_: Exception) {
            return null
        } finally {
            listOf(corners, p0, p1, status, err, from, to, inliers).forEach { it.release() }
        }
    }

    private fun processFrame(t: Int, prevOut: Mat?): Mat {
        val f = frames.getValue(t)
        val out = f.bgr.clone()
        val rem = f.mask.clone()
        try {
            if (Core.countNonZero(rem) == 0) return out

            // 1) Fundo real dos vizinhos, do mais próximo para o mais distante
            for (k in 1..window) {
                for (n in intArrayOf(t + k, t - k)) {
                    val nf = frames[n] ?: continue
                    val tr = transform(t, n) ?: continue
                    fill(out, rem, nf.bgr, nf.notMask, tr)
                }
                if (Core.countNonZero(rem) == 0) return out
            }
            // 2) Quadro anterior já limpo (carrega o fundo recuperado para frente)
            if (prevOut != null) {
                transform(t, t - 1)?.let { fill(out, rem, prevOut, ones, it) }
                if (Core.countNonZero(rem) == 0) return out
            }
            // 3) O que sobrou: reconstrói a partir das bordas
            val dst = Mat()
            Photo.inpaint(out, rem, dst, inpaintRadius, Photo.INPAINT_TELEA)
            dst.copyTo(out)
            dst.release()
            return out
        } finally {
            rem.release()
        }
    }

    /** Copia para [out] os pixels de [src] (alinhado por [tr]) onde ainda falta e [srcValid] permite. */
    private fun fill(out: Mat, rem: Mat, src: Mat, srcValid: Mat, tr: DoubleArray) {
        val m = Mat(2, 3, CvType.CV_64F); m.put(0, 0, *tr)
        val warped = Mat(); val valid = Mat(); val use = Mat()
        val flags = Imgproc.WARP_INVERSE_MAP
        Imgproc.warpAffine(src, warped, m, size, Imgproc.INTER_LINEAR or flags, Core.BORDER_CONSTANT, Scalar(0.0, 0.0, 0.0))
        Imgproc.warpAffine(srcValid, valid, m, size, Imgproc.INTER_NEAREST or flags, Core.BORDER_CONSTANT, Scalar(0.0))
        Core.bitwise_and(rem, valid, use)
        warped.copyTo(out, use)
        Core.subtract(rem, use, rem)
        listOf(m, warped, valid, use).forEach { it.release() }
    }

    /** Transformação que leva coordenadas do quadro t para o quadro n (encadeando os passos). */
    private fun transform(t: Int, n: Int): DoubleArray? {
        var tr = IDENTITY
        if (n > t) {
            for (i in t until n) tr = compose(steps[i] ?: return null, tr)
        } else {
            for (i in t - 1 downTo n) tr = compose(invert(steps[i] ?: return null) ?: return null, tr)
        }
        return tr
    }

    companion object {
        private val IDENTITY = doubleArrayOf(1.0, 0.0, 0.0, 0.0, 1.0, 0.0)

        /** b ∘ a  (aplica a, depois b) — matrizes afins 2x3 em linha */
        private fun compose(b: DoubleArray, a: DoubleArray) = doubleArrayOf(
            b[0] * a[0] + b[1] * a[3], b[0] * a[1] + b[1] * a[4], b[0] * a[2] + b[1] * a[5] + b[2],
            b[3] * a[0] + b[4] * a[3], b[3] * a[1] + b[4] * a[4], b[3] * a[2] + b[4] * a[5] + b[5],
        )

        private fun invert(m: DoubleArray): DoubleArray? {
            val det = m[0] * m[4] - m[1] * m[3]
            if (abs(det) < 1e-9) return null
            val i0 = m[4] / det; val i1 = -m[1] / det
            val i3 = -m[3] / det; val i4 = m[0] / det
            return doubleArrayOf(i0, i1, -(i0 * m[2] + i1 * m[5]), i3, i4, -(i3 * m[2] + i4 * m[5]))
        }
    }
}
