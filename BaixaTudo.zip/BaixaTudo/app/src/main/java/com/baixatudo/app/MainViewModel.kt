package com.baixatudo.app

import android.app.Application
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

/** Formatos de saída que o usuário pode escolher. */
enum class OutputFormat(val qualities: List<String>) {
    MP4(listOf("Melhor", "1080p", "720p", "480p", "360p")),
    MP3(listOf("320 kbps", "256 kbps", "192 kbps", "128 kbps")),
    M4A(emptyList()),
    ORIGINAL(emptyList());
}

data class UiState(
    val engineReady: Boolean = false,
    val busy: Boolean = false,
    val downloading: Boolean = false,
    /** 0..100, ou -1 para barra indeterminada */
    val progress: Int = 0,
    val status: String = "Preparando o motor de download…",
    val detail: String = "",
)

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val _state = MutableStateFlow(UiState())
    val state = _state.asStateFlow()

    @Volatile private var processId: String? = null
    @Volatile private var cancelled = false

    init {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                YoutubeDL.getInstance().init(getApplication())
                FFmpeg.getInstance().init(getApplication())
                _state.update {
                    it.copy(engineReady = true, status = "Pronto! Cole um link para começar.")
                }
            } catch (e: Exception) {
                _state.update { it.copy(status = "Falha ao iniciar o motor: ${e.message}") }
            }
        }
    }

    // ---------------------------------------------------------------- download

    fun download(url: String, format: OutputFormat, quality: String, treeUri: Uri) {
        if (_state.value.busy) return
        val id = UUID.randomUUID().toString()
        processId = id
        cancelled = false

        viewModelScope.launch(Dispatchers.IO) {
            val workDir = File(getApplication<Application>().cacheDir, "dl/$id").apply { mkdirs() }
            _state.update {
                it.copy(busy = true, downloading = true, progress = -1,
                    status = "Analisando o link…", detail = "")
            }
            try {
                val request = buildRequest(url, format, quality, workDir)

                YoutubeDL.getInstance().execute(
                    request,
                    processId = id,
                    callback = { progress, eta, line -> onProgress(progress, eta, line) },
                )

                _state.update { it.copy(progress = -1, status = "Salvando na pasta escolhida…") }
                val files = workDir.listFiles()
                    ?.filter { it.isFile && it.length() > 0 && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") }
                    .orEmpty()
                if (files.isEmpty()) error("Nenhum arquivo foi gerado.")

                val saved = files.map { saveToFolder(it, treeUri) }
                _state.update {
                    it.copy(progress = 100, status = "✅ Concluído!", detail = "Salvo: " + saved.joinToString("\n"))
                }
            } catch (e: Exception) {
                val msg = if (cancelled) "Download cancelado." else "❌ " + friendlyError(e)
                _state.update { it.copy(progress = 0, status = msg, detail = if (cancelled) "" else rawError(e)) }
            } finally {
                workDir.deleteRecursively()
                processId = null
                _state.update { it.copy(busy = false, downloading = false) }
            }
        }
    }

    fun cancel() {
        val id = processId ?: return
        cancelled = true
        YoutubeDL.getInstance().destroyProcessById(id)
    }

    private fun onProgress(progress: Float, eta: Long, line: String) {
        val phase = when {
            "[ExtractAudio]" in line -> "Convertendo o áudio…"
            "[Merger]" in line || "[VideoRemuxer]" in line -> "Juntando vídeo e áudio…"
            "[Metadata]" in line -> "Gravando informações…"
            progress > 0f -> buildString {
                append("Baixando… ${progress.toInt()}%")
                if (eta > 0) append("  •  faltam ${formatEta(eta)}")
            }
            else -> null
        }
        _state.update { s ->
            val converting = phase != null && !phase.startsWith("Baixando")
            s.copy(
                progress = if (converting) -1 else if (progress > 0f) progress.toInt() else s.progress,
                status = phase ?: s.status,
                detail = line.take(200),
            )
        }
    }

    // ------------------------------------------------------- opções do yt-dlp

    private fun buildRequest(url: String, format: OutputFormat, quality: String, dir: File): YoutubeDLRequest {
        val r = YoutubeDLRequest(url)
        // Nome do arquivo = título do vídeo (limitado a 150 bytes)
        r.addOption("-o", "${dir.absolutePath}/%(title).150B.%(ext)s")
        r.addOption("--no-playlist")   // links do YouTube com &list= baixam só o vídeo
        r.addOption("--no-mtime")

        when (format) {
            OutputFormat.MP4 -> {
                val height = quality.removeSuffix("p").toIntOrNull()
                val res = if (height != null) "res:$height" else "res"
                r.addOption("-f", "bv*+ba/b")
                // Prefere H.264 + AAC: toca em qualquer celular, TV ou WhatsApp
                r.addOption("-S", "$res,vcodec:h264,acodec:m4a")
                r.addOption("--merge-output-format", "mp4")
                r.addOption("--remux-video", "mp4")
            }
            OutputFormat.MP3 -> {
                val kbps = quality.filter(Char::isDigit).ifEmpty { "192" }
                r.addOption("-f", "bestaudio/best")
                r.addOption("-x")
                r.addOption("--audio-format", "mp3")
                r.addOption("--audio-quality", "${kbps}K")
                r.addOption("--embed-metadata")
            }
            OutputFormat.M4A -> {
                r.addOption("-f", "bestaudio[ext=m4a]/bestaudio/best")
                r.addOption("-x")
                r.addOption("--audio-format", "m4a")
                r.addOption("--embed-metadata")
            }
            OutputFormat.ORIGINAL -> {
                // Melhor qualidade disponível, sem conversão de formato
                r.addOption("-f", "bv*+ba/b")
            }
        }
        return r
    }

    // ------------------------------------------- copia para a pasta escolhida

    private fun saveToFolder(file: File, treeUri: Uri): String {
        val ctx = getApplication<Application>()
        val dir = DocumentFile.fromTreeUri(ctx, treeUri)
            ?: error("Pasta de destino inválida. Escolha a pasta novamente.")
        if (!dir.canWrite()) error("Sem permissão para gravar na pasta. Escolha a pasta novamente.")

        val mime = when (file.extension.lowercase()) {
            "mp3" -> "audio/mpeg"
            "m4a" -> "audio/mp4"
            "mp4" -> "video/mp4"
            "webm" -> "video/webm"
            "mkv" -> "video/x-matroska"
            else -> "application/octet-stream"
        }
        val target = dir.createFile(mime, file.name)
            ?: error("Não foi possível criar o arquivo na pasta escolhida.")

        ctx.contentResolver.openOutputStream(target.uri)?.use { out ->
            file.inputStream().use { it.copyTo(out, 256 * 1024) }
        } ?: error("Não foi possível gravar o arquivo.")

        return target.name ?: file.name
    }

    // --------------------------------------------------------- atualização

    fun updateEngine() {
        if (_state.value.busy) return
        viewModelScope.launch(Dispatchers.IO) {
            _state.update { it.copy(busy = true, progress = -1, status = "Atualizando o yt-dlp…", detail = "") }
            val msg = try {
                val ctx = getApplication<Application>()
                when (YoutubeDL.getInstance().updateYoutubeDL(ctx)) {
                    YoutubeDL.UpdateStatus.DONE ->
                        "✅ Motor atualizado (versão ${YoutubeDL.getInstance().version(ctx)})."
                    YoutubeDL.UpdateStatus.ALREADY_UP_TO_DATE ->
                        "O motor já está na versão mais recente (${YoutubeDL.getInstance().version(ctx)})."
                    else -> "Atualização concluída."
                }
            } catch (e: Exception) {
                "❌ Falha ao atualizar: ${e.message}"
            }
            _state.update { it.copy(busy = false, progress = 0, status = msg) }
        }
    }

    // ------------------------------------------------------------ helpers

    private fun formatEta(sec: Long): String =
        if (sec >= 60) "${sec / 60}min ${sec % 60}s" else "${sec}s"

    private fun rawError(e: Exception): String =
        (e.message ?: e.toString()).lines().lastOrNull { it.contains("ERROR") }?.take(300)
            ?: (e.message ?: "").take(300)

    private fun friendlyError(e: Exception): String {
        val m = (e.message ?: "").lowercase()
        return when {
            "unsupported url" in m -> "Esse link não é suportado."
            "login" in m || "sign in" in m || "cookies" in m ->
                "O site exige login para esse conteúdo (privado, restrito por idade ou bloqueio temporário)."
            "rate-limit" in m || "429" in m -> "O site bloqueou temporariamente. Tente de novo em alguns minutos."
            "private" in m -> "Esse conteúdo é privado."
            "unable to resolve" in m || "network" in m || "timed out" in m ->
                "Problema de conexão. Verifique sua internet."
            "requested format is not available" in m ->
                "Essa qualidade não está disponível. Tente \"Melhor\" ou outro formato."
            else -> "Não foi possível baixar. Toque em \"Atualizar motor\" e tente de novo."
        }
    }
}
