package com.baixatudo.app

import android.content.ActivityNotFoundException
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.baixatudo.app.databinding.ActivityMainBinding
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private val vm: MainViewModel by viewModels()
    private val prefs by lazy { getSharedPreferences("config", MODE_PRIVATE) }

    private var treeUri: Uri? = null
    private var format = OutputFormat.MP4

    private val pickFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            prefs.edit().putString("tree", uri.toString()).apply()
            treeUri = uri
            showFolder()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        applyTitleGradient()
        restorePrefs()
        setupFormatButtons()
        showFolder()

        b.btnPaste.setOnClickListener { pasteFromClipboard() }
        b.btnFolder.setOnClickListener { pickFolder.launch(treeUri) }
        b.btnDownload.setOnClickListener { startDownload() }
        b.btnCancel.setOnClickListener { vm.cancel() }
        b.btnSubs.setOnClickListener { startActivity(Intent(this, SubtitleActivity::class.java)) }
        b.btnOpenFile.setOnClickListener { vm.state.value.lastFile?.let(::openFile) }
        b.btnOpenFolder.setOnClickListener { openFolder(vm.state.value.lastFile) }
        b.btnShare.setOnClickListener { vm.state.value.lastFile?.let(::shareFile) }

        b.chkExact.isChecked = prefs.getBoolean("exact_cut", false)
        b.chkExact.setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("exact_cut", c).apply() }
        b.chkCut.setOnCheckedChangeListener { _, checked ->
            b.cutRow.visibility = if (checked) View.VISIBLE else View.GONE
            b.startLayout.error = null; b.endLayout.error = null
        }

        b.chkSubs.isChecked = prefs.getBoolean("remove_subs", false)
        b.chkSubs.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("remove_subs", checked).apply()
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                vm.state.collect(::render)
            }
        }

        if (savedInstanceState == null) handleShare(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShare(intent)
    }

    // ------------------------------------------------------------------ UI

    private fun setupFormatButtons() {
        val ids = mapOf(
            OutputFormat.MP4 to R.id.fmtMp4,
            OutputFormat.MP3 to R.id.fmtMp3,
            OutputFormat.M4A to R.id.fmtM4a,
            OutputFormat.ORIGINAL to R.id.fmtOriginal,
        )
        fun select(f: OutputFormat) {
            ids.forEach { (k, id) -> findViewById<View>(id).isSelected = k == f }
        }
        select(format)
        updateQualityOptions()

        ids.forEach { (f, id) ->
            findViewById<View>(id).setOnClickListener {
                if (f == format) return@setOnClickListener
                format = f
                select(f)
                prefs.edit().putString("format", format.name).apply()
                updateQualityOptions()
            }
        }
        b.qualityInput.setOnItemClickListener { _, _, pos, _ ->
            prefs.edit().putInt("quality_${format.name}", pos).apply()
        }
    }

    private fun updateQualityOptions() {
        b.chkSubs.visibility =
            if (format == OutputFormat.MP4 || format == OutputFormat.ORIGINAL) View.VISIBLE else View.GONE
        val items = format.qualities
        b.qualityLayout.visibility = if (items.isEmpty()) View.GONE else View.VISIBLE
        b.qualityLabel.visibility = b.qualityLayout.visibility
        if (items.isEmpty()) return
        val idx = prefs.getInt("quality_${format.name}", if (format == OutputFormat.MP3) 2 else 0)
            .coerceIn(0, items.lastIndex)
        b.qualityInput.setAdapter(ArrayAdapter(this, android.R.layout.simple_list_item_1, items))
        b.qualityInput.setText(items[idx], false)
    }

    /** "BaixaTudo" com o gradiente rosa → branco → ciano da identidade. */
    private fun applyTitleGradient() {
        val t = b.titleText
        t.post {
            val w = t.paint.measureText(t.text.toString())
            t.paint.shader = android.graphics.LinearGradient(
                0f, 0f, w, 0f,
                intArrayOf(0xFFFF9BF0.toInt(), 0xFFE7B8FF.toInt(), 0xFF7DE8FF.toInt(), 0xFF2EE6FF.toInt()),
                floatArrayOf(0f, 0.42f, 0.62f, 1f),
                android.graphics.Shader.TileMode.CLAMP,
            )
            t.invalidate()
        }
    }

    private fun showFolder() {
        val uri = treeUri
        b.folderText.text = if (uri == null) {
            getString(R.string.no_folder)
        } else {
            // "primary:Download/Videos" -> "Armazenamento interno/Download/Videos"
            val docId = runCatching { DocumentsContract.getTreeDocumentId(uri) }.getOrDefault(uri.toString())
            val (vol, path) = docId.split(":", limit = 2).let { it[0] to it.getOrElse(1) { "" } }
            val volName = if (vol == "primary") "Armazenamento interno" else "Cartão SD"
            "$volName/$path".trimEnd('/')
        }
    }

    private fun render(s: UiState) {
        s.openInEditor?.let { uri ->
            vm.editorOpened()
            startActivity(Intent(this, SubtitleActivity::class.java)
                .putExtra(SubtitleActivity.EXTRA_VIDEO, uri.toString()))
        }
        b.statusText.text = s.status
        b.detailText.text = s.detail
        b.detailText.visibility = if (s.detail.isBlank()) View.GONE else View.VISIBLE

        b.btnDownload.isEnabled = s.engineReady && !s.busy
        b.btnCancel.visibility = if (s.downloading) View.VISIBLE else View.GONE
        b.doneActions.visibility = if (s.lastFile != null && !s.busy) View.VISIBLE else View.GONE

        val bar = b.progress
        if (!s.busy && s.progress <= 0) {
            bar.visibility = View.INVISIBLE
        } else {
            val indeterminate = s.progress < 0
            if (bar.isIndeterminate != indeterminate) {
                bar.visibility = View.INVISIBLE
                bar.isIndeterminate = indeterminate
            }
            bar.visibility = View.VISIBLE
            if (!indeterminate) bar.setProgressCompat(s.progress, true)
        }
    }

    // -------------------------------------------------------------- ações

    private fun startDownload() {
        val url = extractUrl(b.urlInput.text?.toString().orEmpty())
        if (url == null) {
            b.urlLayout.error = getString(R.string.invalid_url)
            return
        }
        b.urlLayout.error = null
        val folder = treeUri
        if (folder == null) {
            Toast.makeText(this, R.string.choose_folder_first, Toast.LENGTH_LONG).show()
            pickFolder.launch(null)
            return
        }
        var cut: MainViewModel.Cut? = null
        if (b.chkCut.isChecked) {
            b.startLayout.error = null; b.endLayout.error = null
            val start = parseTime(b.startInput.text?.toString().orEmpty())
            val end = parseTime(b.endInput.text?.toString().orEmpty())
            when {
                start == null -> { b.startLayout.error = getString(R.string.time_invalid); return }
                end == null -> { b.endLayout.error = getString(R.string.time_invalid); return }
                end <= start -> { b.endLayout.error = getString(R.string.time_end_before); return }
            }
            cut = MainViewModel.Cut(start!!, end!!)
        }
        val quality = if (format.qualities.isEmpty()) "" else b.qualityInput.text.toString()
        val removeSubs = b.chkSubs.isChecked && b.chkSubs.visibility == View.VISIBLE
        vm.download(url, format, quality, folder, removeSubs, cut, exact = b.chkExact.isChecked)
    }

    /** Aceita "45", "1:20", "1:20.5", "1:02:03", "1.20" (= 1:20) ou "1m20s". */
    private fun parseTime(raw: String): Double? {
        var t = raw.trim().lowercase().replace(",", ".")
        if (t.isEmpty()) return null
        Regex("""^(?:(\d+)h)?\s*(?:(\d+)m)?\s*(?:(\d+(?:\.\d+)?)s?)?$""").matchEntire(t)?.let { m ->
            if (t.contains('h') || t.contains('m')) {
                val (h, mi, s) = m.destructured
                return (h.toDoubleOrNull() ?: 0.0) * 3600 + (mi.toDoubleOrNull() ?: 0.0) * 60 + (s.toDoubleOrNull() ?: 0.0)
            }
        }
        // "1.20" com um ponto e 2 dígitos depois = minutos.segundos (comum no teclado do celular)
        if (!t.contains(':') && Regex("""^\d+\.\d{2}$""").matches(t)) t = t.replace('.', ':')
        val parts = t.split(":")
        if (parts.size > 3) return null
        var total = 0.0
        for ((i, p) in parts.withIndex()) {
            val v = p.toDoubleOrNull() ?: return null
            if (v < 0 || (i > 0 && v >= 60)) return null
            total = total * 60 + v
        }
        return total
    }

    private fun openFile(uri: Uri) {
        val type = contentResolver.getType(uri) ?: "*/*"
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, type)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try {
            startActivity(Intent.createChooser(i, getString(R.string.open_with)))
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, R.string.no_app_to_open, Toast.LENGTH_SHORT).show()
        }
    }

    private fun shareFile(uri: Uri) {
        val i = Intent(Intent.ACTION_SEND)
            .setType(contentResolver.getType(uri) ?: "*/*")
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(i, getString(R.string.share)))
    }

    /**
     * Abre a pasta onde o arquivo foi salvo. Tenta o gerenciador de arquivos do sistema
     * e, se não houver um que aceite, abre o seletor de arquivos já naquela pasta.
     */
    private fun openFolder(file: Uri?) {
        val tree = treeUri ?: return
        val folder = runCatching {
            DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
        }.getOrNull() ?: return

        val view = Intent(Intent.ACTION_VIEW)
            .setDataAndType(folder, DocumentsContract.Document.MIME_TYPE_DIR)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try {
            startActivity(view)
            return
        } catch (_: ActivityNotFoundException) { }

        val pick = Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*")
            .addCategory(Intent.CATEGORY_OPENABLE)
            .putExtra(DocumentsContract.EXTRA_INITIAL_URI, file ?: folder)
        try {
            startActivity(pick)
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, R.string.no_app_to_open, Toast.LENGTH_SHORT).show()
        }
    }

    private fun pasteFromClipboard() {
        val cm = getSystemService(ClipboardManager::class.java)
        val text = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty()
        val url = extractUrl(text)
        if (url != null) {
            b.urlInput.setText(url)
            b.urlLayout.error = null
        } else {
            Toast.makeText(this, R.string.clipboard_no_link, Toast.LENGTH_SHORT).show()
        }
    }

    private fun handleShare(intent: Intent?) {
        if (intent?.action != Intent.ACTION_SEND) return
        val url = extractUrl(intent.getStringExtra(Intent.EXTRA_TEXT).orEmpty()) ?: return
        b.urlInput.setText(url)
    }

    private fun extractUrl(text: String): String? =
        Regex("""https?://\S+""").find(text)?.value?.trimEnd('.', ',', ')', '"', '\'')

    private fun restorePrefs() {
        format = runCatching { OutputFormat.valueOf(prefs.getString("format", "MP4")!!) }
            .getOrDefault(OutputFormat.MP4)

        // Só reaproveita a pasta se a permissão ainda estiver válida
        val saved = prefs.getString("tree", null)?.let(Uri::parse)
        treeUri = saved?.takeIf { uri ->
            contentResolver.persistedUriPermissions.any { it.uri == uri && it.isWritePermission }
        }
    }
}
