package com.baixatudo.app

import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.baixatudo.app.databinding.ActivityMainBinding
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private val vm: MainViewModel by viewModels()
    private val prefs by lazy { getSharedPreferences("config", MODE_PRIVATE) }

    private var treeUri: Uri? = null
    private var format = OutputFormat.MP4

    private val pickFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            prefs.edit().putString("tree", uri.toString()).apply()
            treeUri = uri
            showFolder()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        restorePrefs()
        setupFormatButtons()
        showFolder()

        b.btnPaste.setOnClickListener { pasteFromClipboard() }
        b.btnFolder.setOnClickListener { pickFolder.launch(treeUri) }
        b.btnDownload.setOnClickListener { startDownload() }
        b.btnCancel.setOnClickListener { vm.cancel() }
        b.btnUpdate.setOnClickListener { vm.updateEngine() }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                vm.state.collect(::render)
            }
        }

        if (savedInstanceState == null) handleShare(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShare(intent)
    }

    // ------------------------------------------------------------------ UI

    private fun setupFormatButtons() {
        val ids = mapOf(
            OutputFormat.MP4 to R.id.fmtMp4,
            OutputFormat.MP3 to R.id.fmtMp3,
            OutputFormat.M4A to R.id.fmtM4a,
            OutputFormat.ORIGINAL to R.id.fmtOriginal,
        )
        b.formatGroup.check(ids.getValue(format))
        updateQualityOptions()

        b.formatGroup.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            format = ids.entries.first { it.value == checkedId }.key
            prefs.edit().putString("format", format.name).apply()
            updateQualityOptions()
        }
        b.qualityInput.setOnItemClickListener { _, _, pos, _ ->
            prefs.edit().putInt("quality_${format.name}", pos).apply()
        }
    }

    private fun updateQualityOptions() {
        val items = format.qualities
        b.qualityLayout.visibility = if (items.isEmpty()) View.GONE else View.VISIBLE
        b.qualityLabel.visibility = b.qualityLayout.visibility
        if (items.isEmpty()) return
        val idx = prefs.getInt("quality_${format.name}", if (format == OutputFormat.MP3) 2 else 0)
            .coerceIn(0, items.lastIndex)
        b.qualityInput.setAdapter(ArrayAdapter(this, android.R.layout.simple_list_item_1, items))
        b.qualityInput.setText(items[idx], false)
    }

    private fun showFolder() {
        val uri = treeUri
        b.folderText.text = if (uri == null) {
            getString(R.string.no_folder)
        } else {
            // "primary:Download/Videos" -> "Armazenamento interno/Download/Videos"
            val docId = runCatching { DocumentsContract.getTreeDocumentId(uri) }.getOrDefault(uri.toString())
            val (vol, path) = docId.split(":", limit = 2).let { it[0] to it.getOrElse(1) { "" } }
            val volName = if (vol == "primary") "Armazenamento interno" else "Cartão SD"
            "📁 $volName/$path".trimEnd('/')
        }
    }

    private fun render(s: UiState) {
        b.statusText.text = s.status
        b.detailText.text = s.detail
        b.detailText.visibility = if (s.detail.isBlank()) View.GONE else View.VISIBLE

        b.btnDownload.isEnabled = s.engineReady && !s.busy
        b.btnUpdate.isEnabled = s.engineReady && !s.busy
        b.btnCancel.visibility = if (s.downloading) View.VISIBLE else View.GONE

        val bar = b.progress
        if (!s.busy && s.progress <= 0) {
            bar.visibility = View.INVISIBLE
        } else {
            val indeterminate = s.progress < 0
            if (bar.isIndeterminate != indeterminate) {
                bar.visibility = View.INVISIBLE
                bar.isIndeterminate = indeterminate
            }
            bar.visibility = View.VISIBLE
            if (!indeterminate) bar.setProgressCompat(s.progress, true)
        }
    }

    // -------------------------------------------------------------- ações

    private fun startDownload() {
        val url = extractUrl(b.urlInput.text?.toString().orEmpty())
        if (url == null) {
            b.urlLayout.error = getString(R.string.invalid_url)
            return
        }
        b.urlLayout.error = null
        val folder = treeUri
        if (folder == null) {
            Toast.makeText(this, R.string.choose_folder_first, Toast.LENGTH_LONG).show()
            pickFolder.launch(null)
            return
        }
        val quality = if (format.qualities.isEmpty()) "" else b.qualityInput.text.toString()
        vm.download(url, format, quality, folder)
    }

    private fun pasteFromClipboard() {
        val cm = getSystemService(ClipboardManager::class.java)
        val text = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty()
        val url = extractUrl(text)
        if (url != null) {
            b.urlInput.setText(url)
            b.urlLayout.error = null
        } else {
            Toast.makeText(this, R.string.clipboard_no_link, Toast.LENGTH_SHORT).show()
        }
    }

    private fun handleShare(intent: Intent?) {
        if (intent?.action != Intent.ACTION_SEND) return
        val url = extractUrl(intent.getStringExtra(Intent.EXTRA_TEXT).orEmpty()) ?: return
        b.urlInput.setText(url)
    }

    private fun extractUrl(text: String): String? =
        Regex("""https?://\S+""").find(text)?.value?.trimEnd('.', ',', ')', '"', '\'')

    private fun restorePrefs() {
        format = runCatching { OutputFormat.valueOf(prefs.getString("format", "MP4")!!) }
            .getOrDefault(OutputFormat.MP4)

        // Só reaproveita a pasta se a permissão ainda estiver válida
        val saved = prefs.getString("tree", null)?.let(Uri::parse)
        treeUri = saved?.takeIf { uri ->
            contentResolver.persistedUriPermissions.any { it.uri == uri && it.isWritePermission }
        }
    }
}
