# BaixaTudo — baixador de vídeos para Android

Cole um link (YouTube, Shorts, Instagram Reels, TikTok, Facebook e centenas de outros sites),
escolha o formato (MP4, MP3, M4A ou Original), a qualidade e a pasta — o app baixa e
converte sozinho. Também aparece no menu **Compartilhar** dos apps: compartilhe o vídeo
com o BaixaTudo e o link já entra preenchido.

Por baixo usa o **yt-dlp** + **FFmpeg** embutidos (biblioteca youtubedl-android 0.18.1).

## Como gerar o APK

1. Instale o **Android Studio** (versão recente) no computador.
2. Descompacte este zip e, no Android Studio, vá em **File → Open** e escolha a pasta `BaixaTudo`.
3. Espere o Gradle sincronizar (na primeira vez baixa bastante coisa).
4. Menu **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
5. Os APKs ficam em `app/build/outputs/apk/debug/`:
   - `app-arm64-v8a-debug.apk` → quase todo celular dos últimos anos (menor)
   - `app-universal-debug.apk` → funciona em qualquer celular (maior)
6. Passe o APK para o celular e instale (permita "instalar apps desconhecidos").

Ou conecte o celular por USB com a depuração ativada e clique em ▶ Run.

## Uso

- **Primeira abertura** demora alguns segundos (o app prepara o motor).
- Escolha a pasta de destino uma vez; ela fica salva.
- **MP4**: vídeo em H.264/AAC (toca em tudo, inclusive WhatsApp). Qualidade até 1080p+.
- **MP3**: só o áudio, 128–320 kbps.
- **M4A**: só o áudio, sem perda de qualidade (mais rápido que MP3).
- **Original**: melhor qualidade disponível, sem conversão.
- **Atualizar motor**: os sites mudam com frequência. Se um download começar a falhar,
  toque aqui primeiro — resolve a maioria dos casos.

## Remover legendas

Toque em **Remover legenda de um vídeo do celular** (ou marque "Remover legendas depois
de baixar", ou compartilhe um vídeo da Galeria com o BaixaTudo):

1. Arraste a barra de tempo até um momento em que a legenda aparece.
2. Arraste o retângulo vermelho para cima da legenda e ajuste pelos cantos.
   Toque fora dele para levá-lo direto ao ponto tocado.
3. **Ver prévia** mostra como vai ficar aquele quadro.
4. **Remover legenda** processa o vídeo inteiro e salva "… (sem legenda).mp4" na pasta.

### Modos

- **Precisa** (padrão): detecta só as letras dentro do retângulo e, rastreando o
  movimento da câmera, copia o fundo *verdadeiro* de outros quadros em que aquele ponto
  estava visível. O que nunca aparece é reconstruído a partir das bordas. É o melhor
  resultado, principalmente em vídeos com a câmera em movimento.
- **Forte**: igual à Precisa, mas pega também textos fracos, finos ou com sombra.
  Use se sobrar pedaço de letra.
- **Rápida**: apaga o retângulo inteiro com um borrão (resultado simples, bem rápido).

A Precisa processa alguns quadros por segundo, então um vídeo de 30 s leva alguns minutos.
Deixe o app aberto (a tela não apaga durante o processamento). A **prévia** da Precisa
processa 3 segundos em volta do momento escolhido, então leva alguns segundos.

Dica: com a câmera totalmente parada e a legenda sempre no mesmo lugar, não existe fundo
"escondido" para recuperar; nesse caso o resultado se parece com o da Forte/Rápida.

## Limitações conhecidas

- **YouTube**: a biblioteca já traz o QuickJS embutido (runtime JavaScript que o yt-dlp
  exige desde o fim de 2025). Se algo falhar, atualize o motor.
- **Instagram/Facebook**: conteúdo privado, de contas fechadas ou com restrição exige login
  (não implementado). Reels públicos normalmente funcionam; o Instagram às vezes bloqueia
  temporariamente após muitos downloads seguidos.
- O download acontece com o app aberto. Se fechar o app no meio, ele é interrompido.

Baixe apenas conteúdo que você tem direito de baixar (seu próprio, domínio público,
Creative Commons ou com autorização do autor).
