# BaixaTudo — baixador de vídeos para Android

Cole um link (YouTube, Shorts, Instagram Reels, Facebook e centenas de outros sites),
escolha o formato (MP4, MP3, M4A ou Original), a qualidade e a pasta — o app baixa e
converte sozinho. Também aparece no menu **Compartilhar** dos apps: compartilhe o vídeo
com o BaixaTudo e o link já entra preenchido.

Por baixo usa o **yt-dlp** + **FFmpeg** embutidos (biblioteca youtubedl-android 0.18.1).

## Como gerar o APK

1. Instale o **Android Studio** (versão recente) no computador.
2. Descompacte este zip e, no Android Studio, vá em **File → Open** e escolha a pasta `BaixaTudo`.
3. Espere o Gradle sincronizar (na primeira vez baixa bastante coisa).
4. Menu **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
5. Os APKs ficam em `app/build/outputs/apk/debug/`:
   - `app-arm64-v8a-debug.apk` → quase todo celular dos últimos anos (menor)
   - `app-universal-debug.apk` → funciona em qualquer celular (maior)
6. Passe o APK para o celular e instale (permita "instalar apps desconhecidos").

Ou conecte o celular por USB com a depuração ativada e clique em ▶ Run.

## Uso

- **Primeira abertura** demora alguns segundos (o app prepara o motor).
- Escolha a pasta de destino uma vez; ela fica salva.
- **MP4**: vídeo em H.264/AAC (toca em tudo, inclusive WhatsApp). Qualidade até 1080p+.
- **MP3**: só o áudio, 128–320 kbps.
- **M4A**: só o áudio, sem perda de qualidade (mais rápido que MP3).
- **Original**: melhor qualidade disponível, sem conversão.
- **Atualizar motor**: os sites mudam com frequência. Se um download começar a falhar,
  toque aqui primeiro — resolve a maioria dos casos.

## Limitações conhecidas

- **YouTube**: desde o fim de 2025 o yt-dlp precisa de um runtime JavaScript (Deno) para
  ter suporte completo ao YouTube, e o Android não tem um. Sem ele, alguns vídeos podem
  vir com menos opções de qualidade ou falhar. Mantenha o motor atualizado.
- **Instagram/Facebook**: conteúdo privado, de contas fechadas ou com restrição exige login
  (não implementado). Reels públicos normalmente funcionam; o Instagram às vezes bloqueia
  temporariamente após muitos downloads seguidos.
- O download acontece com o app aberto. Se fechar o app no meio, ele é interrompido.

Baixe apenas conteúdo que você tem direito de baixar (seu próprio, domínio público,
Creative Commons ou com autorização do autor).
